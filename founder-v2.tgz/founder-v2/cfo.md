# CFO — Paraölçer (v2)

> Araç para birimini "$" yazar; tüm tutarlar **TL**, KDV hariç. Model aylık kurulduğu için "a day" = **ayda ödeyen abone**. Vergi yapısı (GVK 20/B ya da şahıs şirketi) için mali müşavir; bu tavsiye değildir.

## CFO'nun notu

- **Ne değişti:** Pazarlama planı ilk 60 gün ücretli reklam öngörmüyor, gizlilik sayfası GitHub Pages'te hazır. Bu yüzden ₺2.000/ay reklam kalemi sıfırlandı, başlangıç masrafı ₺16.246 → **₺14.246**.
- **Marj:** ödeyen abone-ay başına net ₺33,33, katkı **₺28,33 (%85)**; 250 abonede **%79 kâr marjı**.
- **Başabaş: 17 ödeyen abone / ay** (v1: 87). Sabit gider sadece Apple programı ve alan adı (₺461/ay).
- **1. yıl işletme kârı: ₺42.062**; başlangıç sonrası ₺27.816 (araç tablosu aşağıda). Başlangıç parası **7. ayda** geri döner. Kendini ödeyene kadar gereken nakit **₺14.246**.
- **İzlenecek satır: ödeyen abone sayısı.** Rampa (30 → 250) hâlâ bir tahmin. Panel v2 %4 (50'de 2) diyor; simüle alıcılar olumluya yatkın, gerçek oran altında olabilir.
  - Hacim −%50 (125 abone): 1. yıl kâr ₺18.265, başlangıç sonrası ₺4.019, geri dönüş 11. ay.
  - Hacim −%70 (75 abone): 1. yıl kâr ₺8.746, başlangıç sonrası **−₺5.500** — bu seviyede 1. yıl başlangıç parasını geri getirmez.
- **Marjı iyileştirmenin üç yolu:**
  1. **Ücretli reklamı ancak abone başına edinme maliyeti ölçülünce aç:** ₺2.000/ay reklam başabaşı 17 → 87'ye çıkarır (v1 hesabı).
  2. **Yıllık planı varsayılan yap:** 12 aylık nakit peşin gelir (model aylık dağıtıyor; gerçek nakit tablosu daha iyi).
  3. **Ömür boyu ₺599 yerine ₺999 tutmak** abone başına geliri artırır ama panelde talebi düşürür; 500 adetle sınırlı olduğu için etkisi en fazla ₺200 bin brüt — test et.
- **Kurulun parasal şartları:** birim ekonomisi ✓, 1. yıl kâr ✓ (planda), gerçek ödeme testi ✗ (henüz yok), kanal dışı edinme maliyeti ✗ (bilinmiyor).

Modelin basitleştirdikleri: Kurucu Üye (₺299,99 yıllık, ₺599/₺999 ömür boyu) ilk aylarda abone başı geliri düşürür; Türkiye'de mağazaların ek vergi kesintileri kontrol edilmeli; kurucunun zamanı bedava sayıldı.

---

# Unit economics: Paraölçer Premium (blended: 60% yearly ₺399,99, 40% monthly ₺49,99; prices net of 20% KDV)

Every number below comes from the input file. Nothing is looked up or guessed.

## One paying subscriber-month

| line | per paying subscriber-month |
| --- | ---: |
| Price | $33.33 |
| App Store / Google Play commission (15% small-business rate, of net price) | -$5.00 |
| RevenueCat (free under its revenue threshold — ESTIMATE, verify) | -$0.00 |
| **Contribution** (what each paying subscriber-month leaves to pay the fixed costs) | **$28.33** (85%) |

## The margin that matters

Fixed costs: $461 a month (Apple Developer Program ($99/yr at USD/TRY 49.83, per month) $411, Domain + privacy-policy page hosting (ESTIMATE) $50, Paid ads (none for first 60 days; ₺2.000/ay from month 3 — ESTIMATE) $0).

- **Break-even: 17 paying subscriber-months a day.** Below that you lose money every month.
- **Profit margin at your plan** (250 a day): **79%** of every sale, after every cost.

## Year 1, month by month

| month | paying subscriber-months a day | revenue | profit | cumulative (after $14,246 startup) |
| ---: | ---: | ---: | ---: | ---: |
| 1 | 30 | $1,000 | $389 | -$13,857 |
| 2 | 50 | $1,666 | $956 | -$12,902 |
| 3 | 70 | $2,333 | $1,522 | -$11,380 |
| 4 | 90 | $3,000 | $2,089 | -$9,291 |
| 5 | 110 | $3,666 | $2,655 | -$6,636 |
| 6 | 130 | $4,333 | $3,222 | -$3,414 |
| 7 | 150 | $5,000 | $3,788 | $375 |
| 8 | 170 | $5,666 | $4,355 | $4,730 |
| 9 | 190 | $6,333 | $4,922 | $9,652 |
| 10 | 210 | $6,999 | $5,488 | $15,140 |
| 11 | 230 | $7,666 | $6,055 | $21,195 |
| 12 | 250 | $8,332 | $6,622 | $27,816 |

- **Year 1 operating profit: $42,062** on $55,994 of revenue.
- After the $14,246 startup spend: $27,816.
- Startup money earned back: month 7.
- Cash you need before it pays for itself: **$14,246**.

## What if

| scenario | margin at plan | break-even a day | year 1 profit |
| --- | ---: | ---: | ---: |
| Base plan | 79% | 17 | $42,062 |
| Price -10% | 77% | 19 | $36,463 |
| Volume -20% | 78% | 17 | $32,544 |
| Unit costs +15% | 77% | 17 | $40,802 |

No red flags in these numbers. They are only as good as the inputs: check every cost against a real quote.
