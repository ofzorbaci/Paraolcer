# Operasyon — Paraölçer (v2)

> **v2 (30.10.2026) — uygulamada tamamlananlar:** gizlilik sayfası, uygulama kilidi, tutarları gizleme, otomatik yedek, tüm veriyi silme, "Nasıl hesaplandı?", deneme bitiş hatırlatması, Excel/CSV içe/dışa aktarma, akışa Dünya Bankası altın ve ECB kur geçmişi. **Hâlâ açık (kurulun v2 şartları):** (1) elle fiyatlanan fon/hisse için **fiyat tarihi ve bayatlık uyarısı** skorda görünmeli; (2) **akış yedek planı** — TÜFE günü öncesi izlenen kontrol ve "veri güncelleniyor" durumu; (3) **doğrulanmış örnek hesap seti** (gerçek banka ekstreleriyle mevduat + stopaj), yöntem ekranından linkli; (4) RevenueCat `iosApiKey`/`androidApiKey` hâlâ boş; (5) stopaj oranları 31.12.2026'da bitiyor.

Tek kişilik, sunucusuz bir mobil uygulama. Günlük işin çoğu otomatik (veri akışı GitHub Actions'ta günde 2 kez çalışıyor); kurucunun işi **verinin doğruluğunu korumak, yayın yapmak ve kullanıcıya cevap vermek.**

## 1. Döngü

**Günlük (otomatik + 10 dk kontrol)**
1. 10:15 ve 14:15 (TR): `feed.yml` TCMB sayfalarını okur, doğrular, `feed.json`'u GitHub Pages'e yayımlar. *(müşteri görmez)*
2. Akış hata verirse GitHub e-postası gelir → kurucu kontrol eder. *(müşteri görmez; bozulursa uygulama "son veri: AA.YYYY" gösterir — müşteri görür)*
3. Kullanıcı uygulamayı açar → akışı okur, yoksa kayıtlı, o da yoksa gömülü kopya. Döviz (Frankfurter/ECB, yedek TCMB) ve altın (gold-api.com) telefonda çekilir. *(müşteri görür)*
4. Mağaza yorumları ve destek e-postası: 10 dk. *(müşteri görür)*

**Aylık**
5. **TÜFE günü (her ayın 3'ü civarı, TÜİK takvimine göre):** akış yeni TÜFE'yi aldı mı kontrol et; Aylık Para Karnesi bildirimi gitti mi; X/YouTube içeriği. *(müşteri görür — ürünün kalbi)*
6. TCMB Beklenti Anketi PDF'i: akışın ayrıştırdığını doğrula.
7. RevenueCat panosu: deneme, dönüşüm, iptal rakamları → `marketing.md`'deki üç rakam.

**Olay bazlı**
8. PPK karar günü: politika faizi akışta güncellendi mi; bildirim.
9. **Stopaj oranları:** `feed/withholding.json` ve `src/lib/deposit.ts` — mevcut oranlar 31.12.2026'da sona eriyor; yeni Cumhurbaşkanı Kararı çıkınca aynı gün güncellenmeli (akış süre dolmadan 30 gün önce hata veriyor — yani **1 Aralık 2026 civarı, lansmandan 2 gün önce alarm çalacak**).
10. Expo SDK / mağaza politika güncellemeleri: üç ayda bir.

## 2. Tedarikçiler (CFO'daki her kalem)

| girdi | tedarikçi | fiyat / şart | kaynak | alternatif |
| --- | --- | --- | --- | --- |
| iOS dağıtım + ödeme | Apple Developer Program | $99/yıl; Small Business Program'a ayrı başvuru gerekir (%15) | [developer.apple.com/programs](https://developer.apple.com/programs/), [Small Business Program](https://developer.apple.com/app-store/small-business-program/) | — |
| Android dağıtım + ödeme | Google Play Console | $25 tek sefer; abonelikte %15 | [play.google.com/console](https://play.google.com/console/) | — |
| Abonelik altyapısı | RevenueCat | belli gelir eşiğine kadar ücretsiz (güncel eşik kontrol edilmeli) | [revenuecat.com/pricing](https://www.revenuecat.com/pricing/) | Adapty, Qonversion; ya da doğrudan StoreKit/Billing |
| Derleme/yayın | Expo EAS | ücretsiz katmanda aylık sınırlı derleme; gerekirse ücretli | [expo.dev/pricing](https://expo.dev/pricing) | yerel derleme |
| Veri akışı barındırma | GitHub Actions + Pages | açık repo için ücretsiz | [docs.github.com](https://docs.github.com/en/billing) | Cloudflare Pages |
| TÜFE, faiz, PPK, beklenti | TCMB (EVDS / sayfalar) | ücretsiz, resmi | [evds2.tcmb.gov.tr](https://evds2.tcmb.gov.tr/) — sayfa ayrıştırma yerine **EVDS API** daha dayanıklı | TÜİK |
| Döviz | Frankfurter (ECB), yedek TCMB today.xml | ücretsiz | [frankfurter.app](https://www.frankfurter.app/) | — |
| Altın | gold-api.com | ücretsiz katman, kullanım şartları kontrol edilmeli | [gold-api.com](https://gold-api.com/) | kendi akışına TCMB/borsa kaynağı |
| ENAG | ENAG yayınları | kullanıcı girer / kurucu aylık girer — **yeniden kullanım izni kontrol edilmeli** | — | — |
| Fon fiyatları (gelecek) | TEFAS | **kullanım şartları ve izin için teklif/başvuru gerekir** | [tefas.gov.tr](https://www.tefas.gov.tr/) | lisanslı veri sağlayıcı |
| BIST fiyatları (gelecek) | Borsa İstanbul veri dağıtımı / lisanslı satıcı | **teklif gerekir**; gecikmeli veri bile lisanslı | [borsaistanbul.com veri](https://www.borsaistanbul.com/tr/sayfa/2213/veri-yayin-hizmetleri) | — |
| Alan adı | nic.tr / kayıt firması | ₺50/ay tahmin | [nic.tr](https://www.nic.tr/) | — |

CFO fiyatları değişmedi; `numbers.json` güncellenmedi. Açık soru: TEFAS/BIST verisinin maliyeti (teklif yok) → kurulun şartı, gelecekte CFO'ya eklenecek.

## 3. İnsanlar

Tek kişi: kurucu, tam zamanlı bir işin yanında. Ücret yok (CFO'da kurucu zamanı bedava sayıldı).

| gün | iş | süre |
| --- | --- | --- |
| Her gün | akış/hata e-postası, yorumlar, destek | 10–15 dk |
| Cumartesi | ana video (zaten yapılıyor) + uygulama bölümü | +30 dk |
| Pazar | Haftalık Piyasa Analizi (zaten) + 15 sn uygulama | +10 dk |
| Ayın 3'ü (TÜFE) | kontrol + X + Investing | 1 saat |
| Akşam, haftada 2 | geliştirme (Claude Code ile) | 2 × 2 saat |
| **Toplam** | | **≈ 6–7 saat/hafta** |

İlk ay (lansman): haftada ≈ 12 saat (hata düzeltme, yorum yanıtları). Yardım gerekirse ilk alınacak kişi: destek/yorum yanıtı için yarı zamanlı biri — ücret ve SGK maliyeti mali müşavire sorulmalı.

## 4. Rutinler

**A. TÜFE günü (her ay)**
1. 10:00 TÜİK açıklamasını oku; rakamı not et.
2. 10:15 akış çalıştı mı? GitHub Actions'ta yeşil mi, `feed.json`'da yeni ay var mı?
3. Uygulamayı aç: Özet ekranında "son veri" yeni ayı gösteriyor mu? Bir örnek mevduatın reel getirisini elle (Excel) doğrula.
4. Aylık Para Karnesi bildiriminin tetiklendiğini test cihazında gör.
5. X: tek tweet, gerçek rakam, "yatırım tavsiyesi değildir".
6. Sorun varsa: uygulamada banner ("bu ayın verisi gecikti") — yanlış rakam asla gösterilmez.

**B. Yeni sürüm yayını**
1. `npx tsc --noEmit`, `npx expo lint`, `vitest` hepsi geçmeli.
2. **Yedekleme/geri yükleme testi:** eski sürümde veri gir → yeni sürüme güncelle → veriler duruyor mu? (Cüzdan'ın en büyük şikâyeti bu.)
3. EAS build → TestFlight / Play iç test → 1 gün kendi telefonunda.
4. Yayın notu: ne değişti, sade dil.

**C. Şikâyet / kötü yorum**
1. 24 saat içinde, isimle yanıt (`brand.md` temas noktası 5).
2. Rakam hatasıysa: yeniden üret, yöntem sayfasıyla karşılaştır, gerçekse bugün düzelt ve yorumda tarih ver.
3. İade istenirse: iadenin mağaza (Apple/Google) üzerinden yapıldığını nazikçe ve linkiyle söyle.

**D. Veri akışı hatası**
1. GitHub e-postası → hangi kaynak? (TCMB sayfa yapısı değiştiyse ayrıştırıcı.)
2. Uygulama zaten yedek veriyle çalışır; ekranda tarih görünür.
3. Düzelt, testleri çalıştır, akışı elle tetikle.

**E. Haftalık (Pazartesi, 15 dk)**
1. RevenueCat: deneme, ücretli, iptal.
2. Mağaza: puan, yeni yorumlar.
3. Yol haritasında en çok istenen 1 şey.

## 5. Araçlar

| ihtiyaç | araç | fiyat | neden |
| --- | --- | --- | --- |
| Ödeme / abonelik | App Store + Google Play + RevenueCat | komisyon %15; RevenueCat eşik altı ücretsiz | zaten entegre |
| Analitik | App Store Connect + Play Console + RevenueCat | ücretsiz | hesapsız/gizlilik kararıyla uyumlu; üçüncü taraf takip SDK'sı eklenmez |
| Hata takibi | Sentry (ücretsiz katman) — **opsiyonel** | ücretsiz katman | eklenirse gizlilik politikasında belirtilmeli |
| Destek | tek e-posta adresi (ör. destek@paraolcer…) | alan adıyla | basit |
| Muhasebe | mali müşavir (20/B istisnası ya da şahıs şirketi) | teklif | aşağıda |

## 6. Lisans, izin, vergi — kontrol listesi

Kurallar yere göre değişir ve güncellenir; her madde ilgili kurum ya da bir profesyonelle teyit edilmeli. Hukuki/vergi tavsiyesi değil.

- [ ] **Vergi yapısı:** GVK 20/B "sosyal içerik üreticiliği ve mobil uygulama geliştiriciliği" istisnası (banka üzerinden stopajla, yıllık tutar sınırı) mı, şahıs şirketi mi? → [GİB](https://www.gib.gov.tr/) + mali müşavir. Kurucunun YouTube geliri de aynı istisnayı kullanıyorsa sınır birlikte hesaplanır.
- [ ] **Apple/Google vergi ve banka bilgileri**, Small Business Program başvurusu.
- [x] **Gizlilik politikası URL'si:** `app.json` → `legal.privacyUrl` = `ofzorbaci.github.io/Paraolcer/gizlilik.html` (yayında, veri sorumlusu adı eklendi). Kendi alan adına taşınması önerilir. Veri cihazda kalıyor, ama kur/altın/akış istekleri ve RevenueCat (satın alma kimliği) anlatılmalı.
- [ ] **KVKK:** sunucuda kişisel veri tutulmuyor; yine de aydınlatma metni gerekir mi, VERBİS kaydı gerekir mi → [kvkk.gov.tr](https://www.kvkk.gov.tr/) / avukat.
- [ ] **Kullanım şartları:** şu an Apple'ın standart EULA'sı linkli; yeterli olabilir, Google için de bir şart sayfası.
- [ ] **SPK / yatırım tavsiyesi:** uygulama ölçüm yapar, tavsiye vermez; "yatırım tavsiyesi değildir" her ekranda (mimaride var). "Yenilesem mi?" karşılaştırması **öneri cümlesi kurmamalı** ("şunu yap" değil, "geçmişte şu olurdu"). → SPK mevzuatı için uzman görüşü. Kurucu SPL sürecinde olduğu için kendi lisans kurallarını da kontrol etmeli.
- [ ] **Veri kaynaklarının kullanım şartları:** TCMB (EVDS), gold-api.com, ENAG rakamlarının uygulamada gösterilmesi.
- [ ] **RevenueCat anahtarları:** `iosApiKey` ve `androidApiKey` şu an **boş**; test anahtarı sürümde çökme yapar (kod bunu engelliyor). Yayından önce doldurulmalı.
- [ ] **Marka başvurusu** → `brand.md`.

## 7. Risk kaydı

| # | risk | olasılık | etki | plan |
| --- | --- | --- | --- | --- |
| 1 | TCMB sayfa yapısı değişir, TÜFE gelmez | orta | yüksek | yedek veri + tarih etiketi; EVDS API'ye geçiş; TÜFE günü rutini A |
| 2 | Stopaj oranları 31.12.2026'da biter, yeni karar gecikir | yüksek | yüksek | akış 30 gün önce uyarıyor; karar çıkana kadar ekranda "oranlar teyit bekliyor" |
| 3 | Güncellemede kullanıcı verisi silinir | düşük | çok yüksek | rutin B adım 2; otomatik yedek uygulamada var (`auto-backup.ts`) |
| 4 | Yanlış hesap → güven kaybı / kötü yorum | orta | yüksek | vitest testleri, aylık elle doğrulama, açık yöntem sayfası, rutin C |
| 5 | Mağaza reddi (gizlilik URL'si, finans içeriği, abonelik metni) | orta | orta | lansmandan **en az 2 hafta önce** inceleme gönder; eksikler listede |
| 6 | Bistify ya da bir banka "reel getiri"yi ekler | orta | orta | mevduat/stopaj derinliği, kanal ölçütü, hız |
| 7 | Dönüşüm çok düşük (<%1) | orta | yüksek | fiyat testi B, "Yenilesem mi?" tadımlığı, ömür boyu planı genişlet ya da projeyi yan ürün olarak tut |
| 8 | Kurucunun zamanı biter (iş + kanal + SPL) | yüksek | orta | haftalık 6–7 saat sınırı; otomasyon; yeni özellik yerine bakım önceliği |
| 9 | Ücretsiz döviz/altın API'si kapanır ya da sınırlar | düşük | orta | ikinci kaynak (TCMB) zaten var; altın için yedek kaynak ekle |
| 10 | Mevzuat: "yatırım danışmanlığı" olarak yorumlanma | düşük | yüksek | öneri dili yok, her ekranda uyarı, uzman görüşü |
