# v1 → v2 karşılaştırma (29 → 30 Ekim 2026)

| ölçü | v1 (29 Eki) | v2 (30 Eki, güncel uygulama) |
| --- | ---: | ---: |
| Kurul ortalaması | 5,3 (6/4/6) | 5,7 (6/5/6) |
| Panel (aynı 50 alıcı, tohum 245730) | 1 alır (%2) | 2 alır (%4) |
| Aynı ilk 20 alıcı — uygulama | 1 (P020) | 1 (P016) |
| Aynı ilk 20 alıcı — teklif önerisi | 2 (P016, P020) | 2 (P011, P016) |
| Kabul edilebilir aylık fiyat | ₺16–70 | ₺16–60 |
| Başabaş (ödeyen abone/ay) | 87 (₺2.000 reklamla) | 17 (reklamsız) |
| 1. yıl işletme kârı | ₺18.062 | ₺42.062 |
| Gereken nakit | ₺19.380 | ₺14.246 |
| Karar | Not yet | Not yet |

## Ret sebepleri (50 alıcı)

| sebep | v1 | v2 |
| --- | ---: | ---: |
| habit (abonelik ödemem, banka uygulaması yeter, Excel'im var) | 26 | 22 |
| need (ücretsiz/yeterli) | 17 | 19 |
| convenience (elle fiyat) | 5 | 3 |
| trust (yorum yok) | 2 | 3 |
| price | 0 | 3 |

## Kaybolan itirazlar
"3 varlık yetiyor", "ENAG kilitli", "verim silinir mi", "ilk açılışta form".

## Yeni / kalan itirazlar
1. **Ücretsiz zaten yetiyor** — ayda 1 "Yenilesem mi?" aylık vade yenileyene tam yetiyor.
2. **Geriye dönük** — "dolarda tutsaydın" geçmişi söylüyor; istenen "şimdi hangi faiz/vade enflasyonu yeniyor".
3. **Premium mevduatçıya göre** — döviz/altın tutan kendini dışarıda hissediyor.
4. **Fon/hisse elle fiyat** — 10+ kişinin "fikrimi değiştirir" cevabı.
5. **Tek seferlik ödeme** — ₺200–600 aralığında isteyenler var; ₺999 yüksek.
