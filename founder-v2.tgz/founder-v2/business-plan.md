# Paraölçer · Business plan

**Verdict: Not yet**

> Not: Araç "$" yazar — tüm tutarlar **TL**. "a day" ifadeleri **ayda** (ödeyen abone) olarak okunmalı.

- ✓ Each paying subscriber-month earns $28.33 before fixed costs (85% contribution).
- ✓ Year 1 operating profit: $42,062.
- ✗ 2 of 50 simulated buyers buy (4%, the bar is 25%).

| key number | |
| --- | ---: |
| Price | $33.33 a paying subscriber-month |
| Profit margin at plan | 79% per paying subscriber-month |
| Break-even | 17 paying subscriber-months a day |
| Year 1 operating profit | $42,062 |
| Startup spend | $14,246 |
| Cash needed before it pays for itself | $14,246 |
| Startup money earned back | month 7 |
| Buyer panel | 2 buy · 48 pass |

## The idea

- What it is: A Turkish mobile app (iOS/Android) that shows whether your savings actually beat inflation: the real (inflation-adjusted) return of each holding and of the whole portfolio, in today's lira, against both TÜFE and ENAG — plus a decision screen at each deposit maturity ("Yenilesem mi?").
- Who it is for: Turkish savers who keep their money in TL deposits, USD/EUR and gold (also funds and BIST stocks), especially salaried people who roll over a deposit every month and doubt that official inflation reflects their own.
- What it sells, at what price: Freemium. Free: unlimited holdings, real-return score, ENAG/personal total in one line, one "Yenilesem mi?" result a month, TÜFE-day report card (karne) with a shareable image without amounts, Excel/CSV import and export, sample portfolio and quick deposit card for a first result in under a minute, app lock, hide amounts, automatic backup, delete-all-data, "Nasıl hesaplandı?" method screen. Premium "Aylık Para Karnesi": unlimited "Yenilesem mi?", ENAG/personal inflation per holding, personal inflation basket, purchasing-power chart and time machine, benchmark chart (USD, gram gold, deposit, cash TL — all in real terms), scenarios, "what if you had held USD/deposit", goals and alerts (e.g. real return turns negative), TCMB rate-decision alerts, multiple portfolios. Prices (planned in stores): monthly ₺49,99, yearly ₺399,99, 14-day free trial with an end-of-trial reminder; launch "Kurucu Üye" offer until 31 January 2027: yearly ₺299,99 locked, or lifetime ₺999 for the first 500.
- Where and how: Online, Turkey-wide, Turkish. App Store and Google Play; launch planned for 3 December 2026 (November CPI release day). Official data (TÜİK CPI, TCMB policy rate, PPK calendar, expectations, withholding tax) from a free daily data feed on GitHub Pages; FX from ECB/TCMB, gold from a public API and World Bank history. No server, no account; all financial data stays on the phone. Fund/stock prices are still typed in by the user. Founder runs a ~90,000-subscriber Turkish markets YouTube channel and publishes on Investing Türkiye and X.
- Budget and constraints: Solo founder with a full-time finance job, built with AI coding tools (Expo/React Native). Privacy policy page is live; store API keys not yet set. No paid marketing planned for the first 60 days. Informational only, not investment advice.

## Summary

**Karar: Not yet (henüz değil).** Birim ekonomisi ve 1. yıl kârı geçiyor, alıcı paneli geçmiyor: güncel uygulamayla 50 simüle alıcıdan **2'si** alıyor (**%4**, çıta %25; v1 %2). **Değişmesi gereken:** ücretsiz katman karar anını fazla veriyor ve Premium döviz/altın tutanı konuşmuyor (`/founder-offer`); asıl hakem gerçek alıcı testi (`/founder-launch`). %25 çıtası tek seferlik satışlar için; freemium uygulamada gerçek ücretli dönüşüm çok daha düşük olur.

**Ne ve kim için:** Paraölçer, birikimin bugünün lirasıyla enflasyonu (TÜFE ve ENAG) yenip yenmediğini gösteren ve her vade gününde "Yenilesem mi?" kıyasını yapan hesapsız mobil uygulama. İlk kitle: her ay vade yenileyen, TÜİK'e tam güvenmeyen maaşlı mevduatçı.

**Üç rakam** (`cfo.md`, TL, KDV hariç, projeksiyon): katkı **₺28,33 / abone-ay (%85)**, 250 abonede **%79 marj**; başabaş **17 ödeyen abone/ay**; 1. yıl işletme kârı **₺42.062** (hacim −%70'te başlangıç sonrası −₺5.500).

**v1 → v2 ne değişti:** Ürün kurulun v1 şartlarının çoğunu karşıladı (ilk dakikada sonuç, yöntem ekranı, yedek/kilit, Excel içe aktarma, sınırsız ücretsiz varlık, ENAG özeti). Kurul puanı 5,3 → **5,7**. Panelde "3 varlık yetiyor" ve "ENAG kilitli" itirazları kayboldu; yerine **"ücretsiz zaten yetiyor"** (19 kişi) geldi. Teklif re-testinde (ücretsiz "Yenilesem mi?" sadece sıralama, lira farkı Premium, ömür boyu ₺599) aynı 20 alıcıda 1 → 2 alıcı.

**Kurul ve panel neyde anlaştı:** fon/hisse fiyatının elle girilmesi en kalıcı zayıflık; Premium'un "asıl ne için ödüyorum?" cevabı net değil; yorum yokken güven düşük. **Ayrıldıkları yer:** kurulun Ürün merceği Premium'u daraltmak istiyor; panel ise döviz/altın tutanlar için Premium'da kendine ait bir şey arıyor.

**En büyük risk:** gerçek dönüşümün simülasyonun da altında kalması (abonelik reddi 22 kişi). Plan: kanal üzerinden organik lansman, ilk 30 günde ≥50 yorum, ömür boyu fiyat testi, reklam yok.

**Başlamak için gereken:** **₺14.246** nakit. İlk test: fiyatlı bekleme listesi (21 Kas–2 Ara, ≥1.000 kayıt) ve Kurucu Üye satışı (20 Aralık'a kadar ≥50 ödeyen).

**Bu hafta yapılacak tek şey:** Apple Developer + Google Play hesaplarını aç, abonelik ürünlerini (aylık, yıllık, Kurucu Üye yıllık, ömür boyu) mağazalarda tanımla ve RevenueCat anahtarlarını `app.json`'a gir — 19 Kasım mağaza incelemesinin kritik yolu.

Panel simüle alıcılardır, rakamlar projeksiyondur; finansal, hukuki ya da vergi tavsiyesi değildir.

## What the board said

**Oy: 3 × FUND IF (şartlı fonla)** · Ortalama puan: **5,7 / 10** (Teklif 6, Tekel 5, Ürün 6) — v1: 5,3 (6 / 4 / 6).

Kurul üyeleri yayımlanmış çerçeveleri uygular; o kişiler değildir. Memolar: `board/offers.md`, `board/monopoly.md`, `board/product.md`.

**Ne değişti:** Tekel merceği 4 → 5: dar segment ("vade yenileyen, TÜFE'ye güvenmeyen mevduatçı"), Temettü'nün kapanışı ve hesapsız gizlilik artık bir konumlanma kaması. Ürün merceği ilk 60 saniyenin, yöntem ekranının ve TÜFE günü karnesinin tasarlandığını kabul ediyor. v1'in üç şartı karşılandı: ilk dakikada sonuç, yöntem sayfası, yedek/geri yükleme ve kilit.

### Birden fazla üyenin işaret ettiği riskler

1. **Elle fon/hisse fiyatı hâlâ duruyor** — üçü de. Ürün: bayat fiyat "kendinden emin ama yanlış" bir skor üretir. Tekel: Bistify'ın en güçlü olduğu alan; ya otomatik fiyat ya da bilinçli olarak kapsam dışı.
2. **Premium'un satış nedeni bulanık / ücretsiz katman fazla iyi olabilir** — Teklif ve Ürün. Premium'da 10'dan fazla kalem var; "asıl ne için ödüyorum?" sorusu cevapsız. Aylık tek vade yenileyen biri ayda 1 ücretsiz "Yenilesem mi?" ile yetinebilir.
3. **Kanıt / güven** — Teklif ve Tekel. Yeni sürüm hiç test edilmedi; yorum yok, dağıtım tek kişiye (kanal) bağlı, izleyiciden ödeyene dönüşüm bilinmiyor.
4. **Kopyalanabilirlik** — Tekel: Bistify ENAG ve "yenile?" ekranını bir sürümde ekleyebilir.
5. **Veri akışının TÜFE günü bozulması** — Ürün: sunucusuz akış imza anında herkesin önünde çökebilir.

### Şartlar — kontrol listesi

- [ ] **Ön satış / gerçek ödeme testi**, başarı eşiği önceden yazılı → `/founder-launch`
- [ ] **Premium'u "Yenilesem mi?" etrafında kur**; lansmanda Premium'u çekirdeğe (sınırsız "Yenilesem mi?", varlık bazında ENAG, reel getiri alarmı) indir, gerisini kullanıma göre ekle → `/founder-offer`
- [ ] **Bayat fiyat uyarısı**: elle fiyatlanan her varlıkta fiyat tarihi + skor üzerinde bayatlık işareti; ya da lansmandan önce TEFAS için ilk otomatik kaynak → `/founder-ops`
- [ ] **Akış yedek planı**: son iyi veri, "veri güncelleniyor" durumu, TÜFE öncesi izlenen kontrol → `/founder-ops`
- [ ] **Doğrulanmış örnek hesap seti** (mevduat + stopaj, gerçek banka ekstreleriyle), "Nasıl hesaplandı?"dan linkli → `/founder-ops`
- [ ] **Garanti** (deneme + açık iptal; iade mağazada) → `/founder-offer`
- [ ] **20+ gerçek kullanıcı sonucu** (izinli, anonim) ücretli pazarlamadan önce → `/founder-launch`, `/founder-marketing`
- [ ] **Karne ritüelini kanalın sabit bölümü yap** → `/founder-marketing`
- [ ] **İlk 60 günde dağıtımı kanıtla**: video başına indirme ve deneme→ücretli, eşik önceden → `/founder-launch`
- [ ] **Fon/hisse için karar**: otomatik fiyat planı ya da bilinçli kapsam dışı → `/founder-ops`, `/founder-marketing`

### Ayrılıklar

- **Kapsam:** Ürün merceği Premium'u lansmanda daraltmak istiyor; Teklif merceği "Yenilesem mi?"yi merkeze alıp fiyatı yükseltmeyi bile düşünüyor ("iki katı fiyat isteyebilir misin?"). Tekel merceği ise fon/hisseden bilinçli olarak vazgeçmeyi öneriyor.
- **Fiyat:** Teklif merceği "en ucuz olan" algısından endişeli (₺49,99 vs Bistify ₺79,99); diğerleri fiyatı konu etmiyor.

### Kurulun görebildiği en güçlü versiyon

Paraölçer "her şeyi takip eden portföy uygulaması" olmaya çalışmaz; **vade günü kararının ve TÜFE günü karnesinin uygulaması** olur. Mevduat, döviz ve altın (fiyatı otomatik gelen varlıklar) tam doğrulukla; fon ve hisse ikinci sınıf ama dürüstçe tarih etiketli. Premium'un tek cümlesi: "Her vade gününde ve her TÜFE gününde, paranın gerçek karnesi ve geçmişte ne olurdu kıyası." Kanal her ayın TÜFE gününde aynı karneyi yayınlar; marka bu ritüelden doğar.

## The competition

Kaynak tarihi: 29.10.2026 (dün okunan sayfalar; bugün yeniden okunmadı). Sadece açık kaynaklar. Google Play arama sayfaları otomatik okumaya kapalı; Android tarafı doğrulanamadı.

### 1. Tablo (doğrudan rekabet sırasıyla)

| ad | tür | ne satıyor | reel getiri | fiyat | puan |
| --- | --- | --- | --- | --- | --- |
| [Bistify](https://bistify.net/) | doğrudan | BIST, TEFAS, BES, ABD, altın, döviz, kripto **otomatik fiyatla**; Midas PDF/Excel/BES CSV içe aktarma; FIFO K/Z; temettü; Sharpe/beta; zaman makinesi; PIN/Face ID; **hesap zorunlu** (Google/Apple) | Var — TÜFE aynı grafikte | Ücretsiz + Pro [₺79,99](https://apps.apple.com/tr/app/id6762283764) | 4,9 (15) |
| [FinAIEra](https://finaiera.com/portfoy) | doğrudan (web) | kripto/hisse/döviz, haftalık AI denetimi | Var (TÜFE/CPI) | gösterilmiyor | — |
| [BES Enflasyon Pro](https://apps.apple.com/tr/app/bes-enflasyon-pro/id6633425959) | doğrudan, sadece BES | BES vs enflasyon, ENAG varsayılan | Var (BES) | ₺299,99/6 ay · ₺499,99/yıl | 5,0 (1) |
| [İyi Gelir](https://apps.apple.com/tr/app/i-yi-gelir/id6744439314?l=tr) | dolaylı | fon analizi, alarm, hedef, notlar | Yok | ₺559/ay · ₺5.199,99/yıl | 3,9 (42) |
| [Temettü](https://apps.apple.com/tr/app/id1515109673) | dolaylı — **1 Ocak 2027'de kapanıyor** | BIST + temettü | Yok | yeni abonelik durdu | 4,6 (430) |
| [Cüzdan](https://apps.apple.com/tr/app/id6553987158) | dolaylı | altın, döviz, BIST, kripto | Yok | ücretsiz | 4,5 (78) |
| Hızlı Hesap, FVT, InvestinGoal | ikame | tek seferlik reel getiri hesaplayıcıları | Var, kayıt yok | ücretsiz | — |
| Excel / kafadan hesap | ikame | mevduat faizi vs manşet TÜFE | — | ücretsiz | — |

### 2. Fiyat aralığı (Premium, aylık eşdeğer)

- En düşük: BES Enflasyon Pro yıllık ≈ **₺42/ay**
- Orta: **Bistify Pro ₺79,99** (dönemi gösterilmiyor; aylık varsayılırsa)
- En yüksek: İyi Gelir **₺559/ay** (yıllık ≈ ₺433/ay)

### 3. Konumlandırma haritası

Eksenler: yatay = kapsam (tek hesap ↔ tüm portföy, otomatik fiyat), dikey = enflasyon/karar odağı.

```
         enflasyon + KARAR ürünün merkezi
                    ^
  BES Enflasyon     |   Paraölçer v2 (mevduat/döviz/altın tam,
  Hızlı Hesap/FVT   |   fon/hisse elle; "Yenilesem mi?", karne)
                    |
                    |            Bistify (reel getiri bir grafik,
                    |            otomatik fiyat, risk metrikleri)
 tek hesap ---------+-----------------------------> tüm portföy
                    |   FinAIEra
                    |   İyi Gelir   Cüzdan   Temettü (kapanıyor)
                    v
         enflasyon yok / yan özellik
```

### 4. Şikâyetler (değişmedi)

1. Güncellemede veri kaybı — Cüzdan, 3 yorum ([kaynak](https://apps.apple.com/tr/app/id6553987158)).
2. Fiyat çok yüksek / ani zam — İyi Gelir, 1 yorum (ince).
3. Hesap/şifre sorunu — İyi Gelir, 1 yorum (ince).
4. Eksik varlık türü (fon) — Cüzdan, 1 istek (ince).

### 5. Boşluk — v2'de ne değişti

Paraölçer v2, rakiplerin "hijyen" özelliklerinin çoğunu kapattı: Excel/CSV içe/dışa aktarma, kilit, tutarları gizleme, otomatik yedek, tüm veriyi silme, çoklu portföy, kıyas grafiği, zaman makinesi, alarm/hedef. Bistify'a karşı kalan farklar:

| | Paraölçer v2 | Bistify |
| --- | --- | --- |
| Mevduat (brüt faiz, vade, stopaj) | **Var** | yok |
| ENAG / kişisel enflasyon / kişisel sepet | **Var** | yok |
| Vade günü kararı ("Yenilesem mi?") | **Var** | yok |
| TÜFE günü karnesi + paylaşılabilir görsel | **Var** | yok |
| Hesapsız, veri telefonda | **Var** | hesap zorunlu |
| Fon/hisse otomatik fiyat | **yok (elle)** | Var |
| Midas PDF / BES CSV içe aktarma | yok | Var |
| Temettü, risk metrikleri | yok (bilinçli) | Var |

**Boşluk:** mevduat/döviz/altın tutan tasarruf sahibi için enflasyon + karar uygulaması. Fon/hisse yatırımcısı için Bistify açıkça daha iyi; Paraölçer orada rekabet etmemeli.

### 6. Tehdit

1. **Bistify** — ENAG ve "yenile?" ekranını bir sürümde ekleyebilir (Tekel merceği). Savunma: mevduat derinliği, karne ritüeli, kanal.
2. **Banka uygulamaları** — doğrulanmadı.
3. **Temettü kapanışı iki yönlü:** Temettü kullanıcıları hisse yatırımcısı; büyük kısmı Bistify'a gidecek. Paraölçer'in Temettü'ye özel bir içe aktarıcısı yok (sadece genel Excel/CSV).

## The buyer panel

**2 buy · 48 pass** (4% buy) out of 50 simulated buyers. Seed 245730, so the same cards can be dealt again.

These are simulated buyers, not customers. Use this to find objections and weak spots, then confirm the big ones with real people before you spend.

### By segment

| group | buyers | buy rate |
| --- | ---: | ---: |
| Fund and BIST stock investor (income in TRY) | 10 | 10% |
| Salaried deposit saver (income in TRY) | 20 | 5% |
| Finance enthusiast who watches market YouTube channels (income in TRY) | 5 | 0%  (thin) |
| Holds USD/EUR and gold (income in TRY) | 15 | 0% |

### By buying behaviour

| group | buyers | buy rate |
| --- | ---: | ---: |
| Pays for useful tools | 6 | 17%  (thin) |
| Distrusts official inflation | 6 | 17%  (thin) |
| Reads every review | 4 | 0%  (thin) |
| Free-app only | 11 | 0% |
| Bank app is enough | 8 | 0% |
| Already uses a portfolio app | 4 | 0%  (thin) |
| Spreadsheet keeper | 6 | 0%  (thin) |
| Follows a finance YouTuber | 5 | 0%  (thin) |

### By income

| group | buyers | buy rate |
| --- | ---: | ---: |
| $1,188,000 and up | 17 | 6% |
| $875,000 to $1,188,000 | 17 | 6% |
| under $875,000 | 16 | 0% |

### Why they pass

| reason | buyers | in their words |
| --- | ---: | --- |
| habit | 22 | "I'd download it after the Sunday video and use the free tier, since the free version already shows my deposit's real return against TÜFE, which is all I really want to know. I never pay for app subscriptions, and alarms and charts aren't going to change that." (P003) · "I check my dollars, euros and gold in my bank app and that is enough for me. If I get curious about inflation I can open a free calculator, or just use the free version of this. I don't see what I would pay for." (P004) |
| need | 17 | "I'd download it and use the free tier, but I only roll one 32-day deposit a month, and the free version already gives me one 'Yenilesem mi?' a month plus the real-return view. That covers what I actually do, so I don't see what premium adds for me." (P001) · "I'd download the free version, because a line showing my deposit against ENAG is exactly what I want, and the free monthly 'Yenilesem mi?' already covers my one 32-day renewal. I don't see why I'd pay ₺49,99 a month for more charts and alarms on a deposit I renew the same way every month anyway." (P005) |
| trust | 3 | "It's a brand-new app with no store ratings or comments yet, and I don't pay for anything I can't read reviews on first. The free version already shows my deposit against TÜFE and ENAG, which is mostly what I want, so I'd install that and wait." (P002) · "It's a brand-new app with no store ratings or comments yet, and I don't pay for anything before I've read what other people say. I'd maybe try the free version to see my deposits and gold against inflation, but I don't see why I'd need Premium on top of that." (P015) |
| price | 3 | "I never pay for app subscriptions. The free tier already shows my deposit's real return against TÜFE and ENAG and gives me a monthly 'Yenilesem mi?', and that covers my one 32-day deposit. I'd download it, use the free part, and never upgrade." (P027) · "The free version already tells me what I need: whether my 32-day deposit beats TÜFE, and it gives me one 'Yenilesem mi?' a month, which is exactly how often I renew. I'd download it and use the free tier, but I'm not paying monthly for another app." (P045) |
| convenience | 3 | "I'd maybe download the free version and enter my money market fund once to see the real-return number, but my holdings are mostly funds and BIST stocks, and I'd have to type in their prices myself. That's exactly the chore I don't pay to take on, so I wouldn't upgrade to Premium." (P028) · "Para sorun değil, ₺50 benim için hiçbir şey; ama portföyüm fon ve BIST hissesi ağırlıklı ve fiyatları elle girmem gerekiyorsa bunu iki hafta sonra bırakırım. ENAG satırı için ücretsiz sürümü indirip bakarım, Bistify'ı bırakıp premium'a geçmem." (P033) |

### Why they buy

| reason | buyers | in their words |
| --- | ---: | --- |
| need | 2 | "I don't believe TÜİK's number, so a personal inflation basket and ENAG on every asset is exactly what I'd want to see against my 32-day deposit. I'd try the 14 days and, if my own inflation number looks believable, take the ₺299,99 founder annual since it's cheaper than one dinner out." (P016) · "I already don't believe TÜİK, and a personal inflation basket plus ENAG for every asset is exactly the check I do in my head after every raise. Data stays on my phone with no account, so I'd do the 14-day trial and take the founder yearly at ₺299,99 if the numbers hold up. That's pocket change for me." (P041) |

### What would flip a no

- If after the 14-day trial the renewal reminder plus the dollar/gold/deposit comparison actually changed one of my renewal decisions in a way I can measure in lira, the Kurucu Üye yearly ₺299,99 would be an easy yes.
- A few months of solid store ratings and real user comments saying the numbers hold up, especially the personal inflation calculation.
- If it pulled my balances straight from my bank so I didn't have to type anything, and it clearly told me something my bank app doesn't, like my real return in TL on my FX and gold.
- If the personal inflation basket gave me a real number I trust more than both TÜİK and ENAG for my own spending, I'd pay the ₺299,99 founder annual price. That's about ₺25 a month, which feels fair.
- If fund and BIST stock prices updated automatically, so I didn't have to enter them myself, I might pay a one-time lifetime price. I'd never pay a monthly subscription.
- If it pulled my fund and deposit data automatically from my bank so I didn't have to enter anything, and showed my own real inflation per asset, the lifetime ₺999 might tempt me.
- If the free version stopped covering my monthly renewal check, or if Premium showed me a concrete better deposit or renewal choice that clearly earns more than the subscription costs.
- If after the free trial its 'Yenilesem mi?' and alarms actually showed me something my spreadsheet misses, like my real return dropping below zero before I noticed, I'd consider the founder annual price.
- If the maturity reminder and the 'Yenilesem mi?' check actually got me a better rate when my deposit rolled over, so the app paid for itself on one renewal, I'd take the ₺299,99 founder annual.
- If the deposit renewal reminder and 'Yenilesem mi?' clearly earned me more interest than the subscription costs, or showed me a better rate, I might think about the cheap yearly plan.
- If the lifetime ₺999 offer were still open after I'd used the free version for a couple of months and found myself wanting the alerts and the dollar/gold comparisons, I'd pay once. I would not take a monthly plan.
- Seeing a few hundred real reviews at 4.5+ stars after a few months, plus the free tier actually saving me money on a deposit renewal decision, so the 'Yenilesem mi?' feature proves its worth before I pay.

Buyers say they would buy **1.0 times** in the first month on average.

50 buyers gave all four price answers. Run founder-pricing's van_westendorp.py on the answers folder.

## Pricing

Tüm fiyatlar TL, KDV dahil. Araç çıktılarında "$" = TL.

### 1. Fiyat: aylık ₺49,99 · yıllık ₺399,99 — değişmedi

**Panel (v2, 50 simüle alıcı, aylık fiyat)** — `pricing-curve.md`:

| nokta | v1 (₺79,99 pitch) | v2 (₺49,99 pitch) |
| --- | ---: | ---: |
| PMC | ₺15,81 | ₺15,66 |
| OPP | ₺20,84 | ₺20,84 |
| IPP | ₺35,42 | ₺30,49 |
| PME | ₺69,84 | ₺60,11 |

Kabul edilebilir aralık **₺16–60/ay**. ₺49,99 **aralığın içinde** ama üst bölümde; yıllık ₺399,99 (≈ ₺33,3/ay) IPP'nin hemen üstünde. Not: alıcılar gösterilen fiyata çapalanıyor (pitch ₺79,99 iken PME ₺70, ₺49,99 iken ₺60); aralığın kendisi kesin değil.

- **Fiyat değil, ihtiyaç engel:** v2'de "price" sebebiyle geçen sadece 3 kişi; 19'u "need" (ücretsiz yetiyor), 22'si "habit" (abonelik ödemem). Fiyatı düşürmek bu iki grubu çevirmez.
- **Rakipler:** BES Enflasyon Pro ≈ ₺42/ay, Bistify Pro ₺79,99, İyi Gelir ₺559/ay. Paraölçer yıllıkta en ucuz ikinci.
- **Marj** (`cfo.md`): katkı ₺28,33 / abone-ay, %85.

### 2. Merdiven

| basamak | fiyat | kime |
| --- | --- | --- |
| Ücretsiz | ₺0 | herkes; "param eridi mi?" cevabı |
| Aylık | ₺49,99 | denemek isteyen, taahhüt istemeyen |
| **Yıllık (varsayılan)** | ₺399,99 | asıl satılan plan |
| **Ömür boyu — sadece Kurucu Üye, ilk 500** | **₺599 (öneri; şu an ₺999)** | "aboneliğe para vermem" diyen 22 kişilik grup |

**Ömür boyu fiyatı ₺999 → ₺599'a çekmeyi test et.** Panelde tek seferlik isteyenlerin söylediği aralık ₺150–400 (v1) ve ₺200–300 (v2, P045, P049); ₺999 "çok yüksek" bulundu (P049). ₺599'lu teklif re-testte iki kişide "o zaman alırım" ifadesi çıkardı (P010, P013). Ömür boyu = ≈1,5 yıllık plan; 500 adetle sınırlı olduğu için abonelik gelirini kalıcı olarak yemez.

### 3. Açılış teklifi

Kurucu Üye, lansmandan (3 Aralık 2026) **31 Ocak 2027'ye** kadar: yıllık ₺299,99 abone kaldıkça sabit; ya da ilk 500 kişiye ömür boyu ₺599. Bitiş tarihi gerçek, sahte çapa yok.

### 4. Gerçek alıcıyla test

- **A:** ₺49,99 / ₺399,99 · **B:** ₺39,99 / ₺299,99 (RevenueCat Experiments).
- **Ömür boyu:** ilk 250 kişi ₺599, sonraki 250 ₺799 — hangi hızla tükendiğine bak.
- Ölçü: 1.000 indirme başına net gelir.

### 5. Fiyat itirazları (birebir, panel v2)

1. "₺49,99 a month to confirm my deposit barely keeps up isn't worth it." (P027)
2. "Even ₺50 a month feels like a waste; I'd rather put it toward another gram of gold." (P049)
3. "A one-time purchase of about ₺200–250, much cheaper than the ₺999 lifetime offer, with no recurring charge." (P045)

Simüle cevaplar neyi test edeceğimizi seçer; kanıt değildir.

## The offer

### 1. Mevcut sürüm hangi sorunları çözdü (v1 listesinden)

| v1 sorunu | durum (uygulamada) |
| --- | --- |
| "3 varlık bana yetiyor" | ✓ limit kalktı — itiraz kayboldu |
| "TÜİK benim enflasyonum değil" / ENAG kilitli | ✓ ENAG toplam satırı ücretsiz — itiraz kayboldu, ama yeni sorun doğurdu (aşağıda) |
| İlk dakikada sonuç | ✓ hızlı mevduat kartı, örnek portföy |
| Excel'imde var / taşıma | ✓ Excel/CSV içe ve dışa aktarma (Temettü'ye özel içe aktarıcı yok) |
| Veri kaybı / güven | ✓ otomatik yedek, kilit, gizleme, tüm veriyi sil, "Nasıl hesaplandı?" |
| "Ne yapacağımı söylemiyor" | ◐ "Yenilesem mi?" var; ama geçmişe bakıyor (aşağıda) |
| Fon/hisse elle fiyat | ✗ hâlâ elle |
| Abonelik istemem | ◐ ömür boyu plan var, ₺999 yüksek bulundu |
| Yorum yok / yeni uygulama | ✗ sadece lansmanla çözülür |

### 2. Panelin v2'de söylediği yeni sorunlar

1. **"Ücretsiz zaten yetiyor"** — 19 kişi ("need"). Ayda bir vade yenileyen biri için ayda 1 ücretsiz "Yenilesem mi?" tam ihtiyacı kadar; ENAG satırı da ücretsiz.
2. **"Geriye bakıyor, bana para kazandırmıyor"** — P012, P014, P017: "Dolarda tutsaydın ₺X" geçmişin fotoğrafı; asıl soru "**şimdi hangi banka/vade enflasyonu yeniyor?**".
3. **Premium'u mevduatçıya göre kurmak döviz/altın tutanı dışarıda bırakıyor** — re-testte P013, P019, P020: "Vade Günü Paketi benim için değil."
4. **Kişisel enflasyon sepeti gerçek mi?** — P016, P020: elle girilen bir tahminse değersiz; harcamadan beslenirse değerli.
5. **Abonelik reddi** — 22 kişi "habit"; bir kısmı ₺200–600 tek seferlik ödemeye açık.

### 3. Önerilen paket (re-test edilen)

- **Çekirdek:** "Vade Günü Paketi" — her vadende hatırlatma ve "Yenilesem mi?"nin tamamı **lira olarak** ("aynı koşulla yenileseydin ₺X, dolarda ₺Y, altında ₺Z — bugünün lirasıyla"), 1/3/12 ay; varlık bazında ENAG + kişisel sepet; tam karne; reel getiri alarmı; grafikler; çoklu portföy.
- **Ücretsiz katmanda daraltma:** "Yenilesem mi?" ücretsizde sadece **sıralama** (son 1 ay, hangisi daha iyi korudu); lira farkı ve 3/12 ay Premium. Karne ücretsizde özet.
- **Ömür boyu ₺599** (ilk 500, 31 Ocak 2027'ye kadar).
- Garanti: 14 gün deneme + bitmeden hatırlatma + mağazadan tek dokunuşla iptal.

### 4. Değer denklemi (1–10)

| unsur | v1 | v2 (uygulama) | v3 (öneri) | ne değiştirdi |
| --- | ---: | ---: | ---: | --- |
| Hayal edilen sonuç | 5 | 7 | 7 | karar ekranı var; ama geçmişe dönük |
| Elde etme ihtimali (güven) | 4 | 6 | 6 | yöntem ekranı, kilit, yedek; yorum yok |
| Süre | 6 | 8 | 8 | ilk dakikada sonuç |
| Çaba | 4 | 6 | 6 | Excel içe aktarma; fon/hisse hâlâ elle |

### 5. Re-test — aynı tohum, aynı ilk 20 alıcı

| sürüm | alan | sebep dağılımı |
| --- | ---: | --- |
| v1 (₺79,99, 3 varlık) | 1/20 (P020) | need 10 · habit 8 · trust 2 |
| v1 teklif önerisi (dünkü) | 2/20 (P016, P020) | need 10 · habit 6 · trust 4 |
| **v2 = şu anki uygulama** | **1/20 (P016)** | habit 9 · need 8 · trust 3 |
| **v3 = bu paket** | **2/20 (P011, P016)** | need 10 · habit 7 · trust 3 |

- v3, ücretsiz "Yenilesem mi?"yi sıralamaya indirince **vade yenileyen mevduatçıyı** (P011) kazandı.
- Ama **döviz/altın tutan** üç kişi (P013, P019, P020) Premium'u "benim için değil" diye reddetti; P020 v1'de alıyordu. Premium'un adı ve vitrini sadece mevduatçıyı konuşmamalı.
- Ömür boyu ₺599 iki kişide "o zaman alırım"a yaklaştırdı (P010, P013), ikisi de satın almaya dönüşmedi.

**Dürüst okuma:** 20 kişide 1–2 alıcı arası oynama istatistiksel gürültü sınırında. Teklif tarafında kazanılabilecek şeyin çoğu alındı; kalan engeller **ürün** (fon/hisse fiyatı, ileriye dönük mevduat faizi karşılaştırması), **güven** (yorum) ve **pazar alışkanlığı** (abonelik reddi). Sonraki adım panel değil, gerçek alıcı testi.

### 6. Ürüne geri bildirim (öncelik sırası)

1. **Ücretsiz "Yenilesem mi?"yi sıralamaya indir;** lira farkı ve 3/12 ay Premium (`renew/[id].tsx`, `entitlements.ts`).
2. **Premium vitrinini iki kitleye böl:** paywall'da mevduatçıya "Vade Günü", döviz/altın tutana "reel getiri alarmı + kişisel sepet + kıyas" (bağlamsal `feature` zaten var).
3. **İleriye dönük karar:** vade günü "bugün ilan edilen mevduat faizleriyle yenilersen beklenen reel getiri" — TCMB'nin yayımladığı ortalama mevduat faizi ve beklenti anketiyle (banka bazında veri lisans/kaynak kontrolü gerektirir).
4. **Ömür boyu ₺599 testi.**
5. **Fon fiyatları (TEFAS)** — en çok tekrar eden "fikrimi değiştirir" cevabı (10+ kişi).

## The numbers

> Araç para birimini "$" yazar; tüm tutarlar **TL**, KDV hariç. Model aylık kurulduğu için "a day" = **ayda ödeyen abone**. Vergi yapısı (GVK 20/B ya da şahıs şirketi) için mali müşavir; bu tavsiye değildir.

### CFO'nun notu

- **Ne değişti:** Pazarlama planı ilk 60 gün ücretli reklam öngörmüyor, gizlilik sayfası GitHub Pages'te hazır. Bu yüzden ₺2.000/ay reklam kalemi sıfırlandı, başlangıç masrafı ₺16.246 → **₺14.246**.
- **Marj:** ödeyen abone-ay başına net ₺33,33, katkı **₺28,33 (%85)**; 250 abonede **%79 kâr marjı**.
- **Başabaş: 17 ödeyen abone / ay** (v1: 87). Sabit gider sadece Apple programı ve alan adı (₺461/ay).
- **1. yıl işletme kârı: ₺42.062**; başlangıç sonrası ₺27.816 (araç tablosu aşağıda). Başlangıç parası **7. ayda** geri döner. Kendini ödeyene kadar gereken nakit **₺14.246**.
- **İzlenecek satır: ödeyen abone sayısı.** Rampa (30 → 250) hâlâ bir tahmin. Panel v2 %4 (50'de 2) diyor; simüle alıcılar olumluya yatkın, gerçek oran altında olabilir.
  - Hacim −%50 (125 abone): 1. yıl kâr ₺18.265, başlangıç sonrası ₺4.019, geri dönüş 11. ay.
  - Hacim −%70 (75 abone): 1. yıl kâr ₺8.746, başlangıç sonrası **−₺5.500** — bu seviyede 1. yıl başlangıç parasını geri getirmez.
- **Marjı iyileştirmenin üç yolu:**
  1. **Ücretli reklamı ancak abone başına edinme maliyeti ölçülünce aç:** ₺2.000/ay reklam başabaşı 17 → 87'ye çıkarır (v1 hesabı).
  2. **Yıllık planı varsayılan yap:** 12 aylık nakit peşin gelir (model aylık dağıtıyor; gerçek nakit tablosu daha iyi).
  3. **Ömür boyu ₺599 yerine ₺999 tutmak** abone başına geliri artırır ama panelde talebi düşürür; 500 adetle sınırlı olduğu için etkisi en fazla ₺200 bin brüt — test et.
- **Kurulun parasal şartları:** birim ekonomisi ✓, 1. yıl kâr ✓ (planda), gerçek ödeme testi ✗ (henüz yok), kanal dışı edinme maliyeti ✗ (bilinmiyor).

Modelin basitleştirdikleri: Kurucu Üye (₺299,99 yıllık, ₺599/₺999 ömür boyu) ilk aylarda abone başı geliri düşürür; Türkiye'de mağazaların ek vergi kesintileri kontrol edilmeli; kurucunun zamanı bedava sayıldı.

---

## Unit economics: Paraölçer Premium (blended: 60% yearly ₺399,99, 40% monthly ₺49,99; prices net of 20% KDV)

Every number below comes from the input file. Nothing is looked up or guessed.

### One paying subscriber-month

| line | per paying subscriber-month |
| --- | ---: |
| Price | $33.33 |
| App Store / Google Play commission (15% small-business rate, of net price) | -$5.00 |
| RevenueCat (free under its revenue threshold — ESTIMATE, verify) | -$0.00 |
| **Contribution** (what each paying subscriber-month leaves to pay the fixed costs) | **$28.33** (85%) |

### The margin that matters

Fixed costs: $461 a month (Apple Developer Program ($99/yr at USD/TRY 49.83, per month) $411, Domain + privacy-policy page hosting (ESTIMATE) $50, Paid ads (none for first 60 days; ₺2.000/ay from month 3 — ESTIMATE) $0).

- **Break-even: 17 paying subscriber-months a day.** Below that you lose money every month.
- **Profit margin at your plan** (250 a day): **79%** of every sale, after every cost.

### Year 1, month by month

| month | paying subscriber-months a day | revenue | profit | cumulative (after $14,246 startup) |
| ---: | ---: | ---: | ---: | ---: |
| 1 | 30 | $1,000 | $389 | -$13,857 |
| 2 | 50 | $1,666 | $956 | -$12,902 |
| 3 | 70 | $2,333 | $1,522 | -$11,380 |
| 4 | 90 | $3,000 | $2,089 | -$9,291 |
| 5 | 110 | $3,666 | $2,655 | -$6,636 |
| 6 | 130 | $4,333 | $3,222 | -$3,414 |
| 7 | 150 | $5,000 | $3,788 | $375 |
| 8 | 170 | $5,666 | $4,355 | $4,730 |
| 9 | 190 | $6,333 | $4,922 | $9,652 |
| 10 | 210 | $6,999 | $5,488 | $15,140 |
| 11 | 230 | $7,666 | $6,055 | $21,195 |
| 12 | 250 | $8,332 | $6,622 | $27,816 |

- **Year 1 operating profit: $42,062** on $55,994 of revenue.
- After the $14,246 startup spend: $27,816.
- Startup money earned back: month 7.
- Cash you need before it pays for itself: **$14,246**.

### What if

| scenario | margin at plan | break-even a day | year 1 profit |
| --- | ---: | ---: | ---: |
| Base plan | 79% | 17 | $42,062 |
| Price -10% | 77% | 19 | $36,463 |
| Volume -20% | 78% | 17 | $32,544 |
| Unit costs +15% | 77% | 17 | $40,802 |

No red flags in these numbers. They are only as good as the inputs: check every cost against a real quote.

## Marketing

> **v2 değişiklikleri (30.10.2026):** Uygulama artık paylaşılabilir karne görseli, "Nasıl hesaplandı?" ekranı, alarm/hedef ve Excel içe aktarma içeriyor; hook'lar bunlara göre güncellendi. Konumlandırma mevduatçıda kalıyor, döviz/altın tutana ikinci mesaj eklendi. Temettü dalgası küçültüldü (kullanıcıları hisse yatırımcısı; fon/hisse fiyatı hâlâ elle). Ücretli reklam: ilk 60 gün yok (CFO başabaş 17 abone).

Kanıtlar: `panel/results.md` (v2, 50 alıcı, güncel uygulama), `panel-offer` (teklif re-testi, 20 alıcı), `competitors.md`, `offer.md`, `pricing.md`, `cfo.md`.

**Lansman günü: Perşembe 3 Aralık 2026** — TÜİK'in kasım TÜFE'sini açıkladığı gün. Ürünün kendisi "TÜFE günü karnesi" olduğu için lansman da o güne bağlanıyor. Kampanya: 19 Kasım → 19 Aralık.

### 1. Konumlandırma

Panelde alanlar: **maaşlı, her ay vade yenileyen mevduatçı** (P016, re-testte P011) ve **TÜİK'e güvenmeyen, kendi enflasyonunu isteyen** (P041). Döviz/altın tutanlar re-testte "Vade Günü" vitrinini "benim için değil" diye reddetti (P013, P019, P020) — onlara ikinci mesaj gerekiyor. Fon/hisse yatırımcıları elle fiyat yüzünden geçiyor; ilk kitle onlar değil, Temettü kullanıcılarının çoğu hisse yatırımcısı olduğu için Temettü dalgası küçültüldü.

1. **(Önerilen)** "Her ay vadesini yenileyen ve 'param gerçekten büyüyor mu?' diye düşünen tasarruf sahibi için, Paraölçer; mevduat, dolar ve altını stopaj sonrası TÜFE **ve** ENAG'a göre aynı ekranda ölçen tek reel getiri karnesidir — tek seferlik hesaplayıcıların aksine birikimini hatırlar, portföy uygulamalarının aksine mevduatı doğru hesaplar."
   *Kanıt:* need gerekçelerinin çoğu "vade yenilerken ne yapacağımı söylemiyor"; P016 bu yüzden aldı; hesaplayıcılar kayıt tutmuyor; Bistify/FinAIEra mevduat/stopaj modellemiyor (`competitors.md`).
2. "TÜİK rakamına güvenmeyenler için: kendi enflasyonunla ölç." *Kanıt:* panelde 13 kişi TÜFE'ye güvenmiyor. Ama tek başına politik ve kırılgan bir mesaj; ikinci mesaj olarak kullanılmalı.
3. "Temettü kapanıyor: portföyünü 1 dakikada taşı, üstüne reel getirini gör." *Kanıt:* Temettü'nün 430 değerlendirmesi ve 1 Ocak 2027 kapanışı. Güçlü ama süreli (Ocak sonrası geçersiz) → kampanya içinde bir dalga.

### 2. Kanallar

| kanal | neden bu alıcı | maliyet | işe yaradığını nasıl anlarız | karar |
| --- | --- | --- | --- | --- |
| **Kendi YouTube kanalı (≈90 bin)** | panelde "Follows a finance YouTuber" ve "Sunday video" en sık geçen güven kaynağı | ₺0 (zaman) | açıklama linkinden indirme (UTM / mağaza kampanya linki) | **BAŞLA** — ana kanal |
| **X (tek tweet, görselli)** | TÜFE günü finans gündeminin aktığı yer; "Paraölçer reel getirisi" ölçütünü kurmak için | ₺0 | tweet başı link tıklaması | **BAŞLA** |
| **Investing Türkiye yazısı** | aynı kitle, arama trafiği | ₺0 | yazıdan tıklama | **BAŞLA** (kısa, videoya/uygulamaya yönlendiren) |
| YouTube Shorts / Ekonomi Sözlüğü serisi | "reel getiri" tanımı = kısa video formatına birebir | ₺0 | Shorts → kanal → uygulama | ek, haftada 1 |
| Ücretli reklam (Meta/Google UAC) | — | ₺2.000/ay (tahmin) | — | **YAPMA (ilk 60 gün)** — CFO v2: reklamsız başabaş 17 abone; aşağıdaki azami edinme maliyeti reklamı kârsız gösteriyor |
| Diğer finans YouTuber'ları ile ücretli işbirliği | güven transferi | bilinmiyor | — | **SONRA** — önce kendi kanalının dönüşümü ölçülsün; yapılırsa "reklam/işbirliği" açıkça belirtilir |
| Ekşi/Reddit/Telegram grupları | — | ₺0 | — | **YAPMA** — kurucunun markasına spam riski |

### 3. 30 günlük kampanya (19 Kasım – 19 Aralık 2026)

Kanal ritmi: Cumartesi = özel ana video, Pazar = Haftalık Piyasa Analizi.

| tarih | kanal | ne çıkıyor |
| --- | --- | --- |
| Per 19 Kas (L−14) | X | Teaser: "2021'de 100 bin TL'lik mevduat bugün kaç para? Cevabı bir uygulamaya çevirdim. 3 Aralık." + Kurucu Üye bekleme listesi linki |
| Cmt 21 Kas | YouTube (ana video) | "Mevduat, dolar, altın: son 5 yılda hangisi gerçekten kazandırdı? (TÜFE ve ENAG'a göre)" — sonunda uygulamanın ilk ekranı ve bekleme listesi |
| Paz 22 Kas | Haftalık Piyasa Analizi | sonda 20 sn: "Uygulamayı 3 Aralık'ta TÜFE günü açıyorum, bekleme listesi açıklamada" |
| Sal 24 Kas | Shorts | Ekonomi Sözlüğü: "Reel getiri nedir?" (Fisher formülü, 45 sn) |
| Per 26 Kas | X | "Yapım aşaması": stopajlı mevduat hesabının formülü, tek görsel — güven için yöntem açık |
| Cmt 28 Kas | YouTube (ana video) | "Maaş zammın enflasyonu karşıladı mı? Kendin hesapla" — uygulamadaki maaş hesabı ekranı |
| Paz 29 Kas | Haftalık Piyasa Analizi | sonda: Temettü kapanıyor → "dışa aktarma dosyanı Paraölçer'e taşıyabileceksin" |
| Sal 1 Ara | X + Investing | "Perşembe TÜFE açıklanıyor. Paraölçer aynı gün yayında." |
| **Per 3 Ara (LANSMAN, TÜFE günü)** | X (10:00 TÜFE'den hemen sonra) | "Kasım TÜFE açıklandı. Mevduat bu ay reel olarak %X kazandırdı / kaybettirdi. Kendi birikimin için: Paraölçer, bugün App Store ve Google Play'de." (gerçek rakam, açıklamadan sonra) |
| Per 3 Ara | Investing Türkiye | kısa yazı: "Kasım TÜFE'si sonrası mevduat, dolar ve altının reel getirisi" + uygulama linki |
| Per 3 Ara | Bekleme listesi | e-posta/mesaj: "Yayındayız. Kurucu Üye fiyatı 31 Ocak'a kadar" |
| Cmt 5 Ara | YouTube (ana video) | "Paranın karnesi: Kasım'da kim korudu, kim eritti?" — uygulamanın canlı kullanımı, 14 gün deneme ve Kurucu Üye |
| Paz 6 Ara | Haftalık Piyasa Analizi | açıklamada link, sonda 15 sn |
| Sal 8 Ara | Shorts | "Mevduatını yenilemeden önce 1 dakika: stopaj sonrası reel getiri" |
| Per 10 Ara | X | ilk hafta açık rakamları (indirme, gerçek sayı) + en çok istenen özellik — **sahte sayı yok** |
| Cmt 12 Ara | YouTube (ana video) | "Temettü kapanıyor: portföyünü nereye taşımalısın?" — taşıma bonusu, tarafsız karşılaştırma |
| Paz 13 Ara | Haftalık Piyasa Analizi | link |
| Sal 15 Ara | X | ilk gerçek kullanıcı karnelerinden biri (izinli, tutarsız paylaşılabilir görsel — uygulamada hazır) |
| Per 17 Ara | X + Investing | PPK haftası (karar tarihi PPK takviminden teyit edilmeli): "Faiz kararı mevduatının reel getirisini nasıl değiştirir?" + bildirim özelliği |
| Cmt 19 Ara (L+16) | YouTube (ana video) | Yıl sonu: "2026'da paranın gerçek karnesi" — Kurucu Üye hatırlatması (31 Ocak) |

**Yeni bir şey yokken:** "yöntem" paylaşımları (formüller, TÜİK/ENAG farkı), kullanıcıların sorduğu sorular, yapım aşaması (veri akışı nasıl çalışıyor), yol haritası oylaması (fon fiyatları otomatik olsun mu?).

### 4. On hook

| # | format | hook | cevapladığı itiraz / sebep |
| --- | --- | --- | --- |
| 1 | video açılışı (3 sn) | "Mevduatın %45 kazandırdı. Ama gerçekten kazandırdı mı?" | "zaten biliyorum" |
| 2 | video açılışı | "Bankan sana nominal faizi söyler. Gerçek faizi kimse söylemez." | "bankam ekler" |
| 3 | X | "TÜFE'ye göre kazandın, ENAG'a göre kaybettin. İkisini aynı ekranda gör." | "TÜİK benim enflasyonum değil" |
| 4 | video açılışı | "Vaden yarın doluyor. Yenile mi, dolar mı, altın mı?" | "ne yapacağımı söylemiyor" |
| 5 | X / Shorts | "Maaşına zam geldi. Kaç lira kayıptasın?" | maaş sorusu (P017) |
| 6 | mağaza başlığı | "Hesap yok. Veri telefonunda. Sonuç bir dakikada." | güven, veri gizliliği |
| 7 | video açılışı | "Excel'de enflasyon takip edenler: dosyanı at, gerisini uygulama yapsın." | spreadsheet keeper |
| 8 | X | "Dolar ve altın tutanlar: reel getirin eksiye düşünce haber verelim." | döviz/altın tutan ("Vade Günü benim için değil") |
| 9 | mağaza / paywall | "Ücretsiz: param eridi mi? Premium: vade günü ne yapmalıyım?" | "ücretsiz yetiyor" |
| 10 | video açılışı | "Formülü gizli olan hesaba güvenme. Bizimki açık." | "rakamlar doğru mu?" |

Yasal not: "yatırım tavsiyesi değildir" her videoda/paylaşımda; getiri vaadi yok ("kazandırır" değil, "ölçer"). Bu hukuki tavsiye değil; SPK/reklam kuralları için bir uzmana danışılmalı.

### 5. Bütçe ve rakamlar

**Bütçe (ilk 60 gün):** ₺0 ücretli medya. CFO'nun ₺10.000 lansman kalemi: ₺5.000 mağaza görselleri ve kısa tanıtım videosu, ₺5.000 yedek (60. günden sonra en iyi çalışan kanalda test). CFO v2 modelinde ücretli reklam yok; 60. günden sonra ancak edinme maliyeti ölçülerek açılır (₺2.000/ay başabaşı 17 → 87 aboneye çıkarır).

**Bir müşteriye ödenebilecek azami tutar:**
- Katkı: ₺28,33 / abone-ay (`cfo.md`). Panelde alanlar ilk ay ortalama 1 kez alıyor (yıllık plan).
- Yıllık plan ilk yıl katkısı: ₺399,99 ÷ 1,20 × 0,85 = **₺283**.
- Başlangıç masrafını tehlikeye atmadan, 4 ayda geri dönen bir edinme maliyeti: 4 × ₺28,33 ≈ **₺113 / ödeyen abone**.
- Ücretsiz→ücretli dönüşüm %2,5 (tahmin) ise: ₺113 × 0,025 ≈ **₺2,8 / indirme**. Türkiye'de ücretli uygulama yükleme maliyeti bunun üzerindeyse ücretli reklam kârsızdır — bu yüzden ilk 60 gün organik.

**Haftalık izlenecek üç rakam:**

| rakam | nereden | "bir şey değiştir" eşiği |
| --- | --- | --- |
| Video/tweet başına indirme | mağaza kampanya linkleri | ana video başına < 300 indirme → hook ve çağrıyı değiştir |
| Deneme başlatma oranı (indirenlerin) | RevenueCat | < %8 → paywall'ı ve "Yenilesem mi?" tadımlığını değiştir |
| Deneme → ücretli | RevenueCat | < %30 → deneme süresi içinde ilk karne gelmiyor mu, kontrol et; fiyat testi B (₺39,99/₺299,99) |

(Eşikler tahmin; ilk iki haftanın gerçek rakamlarıyla güncellenmeli.)

## Brand

> **v2 (30.10.2026):** Ad, renk, yazı tipi ve ses değişmedi. Uygulamada hazır olanlar: gizlilik sayfası (`ofzorbaci.github.io/Paraolcer/gizlilik.html`), tutarsız paylaşılabilir karne görseli (temas noktası 4 için), yöntem ekranı, mağaza yorumu isteme. Hâlâ açık: TÜRKPATENT ön araştırması, alan adı (gizlilik sayfasını kendi alan adına taşımak güveni artırır), hesap adları.

Ad (**Paraölçer**) ve logo konsepti (gösterge kadranlı "P") kurucu tarafından zaten seçildi ve uygulamaya işlendi (`app.json`, `assets/brand/paraolcer-icon.svg`, `src/constants/theme.ts`). Bu dosya seçimi konumlandırmaya göre sınar, kontrol listesini verir ve sesi/temas noktalarını yazar.

### 1. Ad adayları (karşılaştırma için 10)

| ad | tarz | ne söylüyor | sesli / ikonda | risk |
| --- | --- | --- | --- | --- |
| **Paraölçer** (seçili) | tanımlayıcı | "paranı ölçer" — ürünün tam işi | kolay, 4 hece; ikonda "P" | "ö" harfi: mağaza araması, alan adı ve URL'de "paraolcer" yazılır; marka tescilinde tanımlayıcı sayılma riski |
| Reel Getiri Pusulası | tanımlayıcı | eski çalışma adı | uzun, ikonda çalışmaz | jenerik |
| Gerçek Getiri | tanımlayıcı | repo adı | net ama jenerik | tescil zor |
| Alım Gücü | tanımlayıcı | maaş/birikim tarafı | net | jenerik ifade |
| Erime | çağrışımlı | "param eriyor mu?" | akılda kalır, olumsuz | negatif his |
| Karne | çağrışımlı | aylık para karnesi | sıcak, Türkçe | çok genel kelime |
| Terazi | çağrışımlı | ölçmek, denge | kısa | başka finans markalarıyla çakışma ihtimali |
| Reelim | uydurma | "benim reel getirim" | kısa, ikona uygun | anlamı ilk duyuşta belirsiz |
| SPA Ölçer | kurucunun markası | kanal (SerbestPiyasaAnaliz) ile bağ | kanal kitlesine tanıdık | uygulama kanaldan bağımsız büyüyemez |
| Enflasyonmetre | tanımlayıcı | doğrudan enflasyon | uzun | jenerik, politik çağrışım |

**Kısa liste:** Paraölçer, Karne, Reelim. **Öneri: Paraölçer'de kal.** Konumlandırmayla birebir ("ölçer" = karne/ölçüt), rakiplerin adlarına (Bistify, Cüzdan, Temettü, İyi Gelir, FinAIEra) benzemiyor, ürün zaten bu adla hazır. "Aylık Para Karnesi" Premium'un adı olarak "Karne"nin sıcaklığını zaten taşıyor.

#### Kurucunun bitirmesi gereken kontroller

Sadece açık aramalar yapabiliyorum; tescil bir marka vekili/avukat tarafından doğrulanır ve kurucu tescil ettirene kadar hiçbir şey tescilli değildir. Bu hukuki tavsiye değil.

- **Marka (Türkiye):** [TÜRKPATENT marka araştırma](https://www.turkpatent.gov.tr/arastirma-yap?form=trademark) — "paraölçer", "paraolcer", "para ölçer" için **Nice sınıfları 9** (indirilebilir yazılım/uygulama), **36** (finansal bilgi hizmetleri), **42** (SaaS/yazılım hizmeti). Yurt dışı gerekirse [EUIPO eSearch](https://euipo.europa.eu/eSearch/) ve [WIPO Global Brand Database](https://branddb.wipo.int/).
  - Not: "Para" + "ölçer" tanımlayıcı sayılabilir; logolu (şekil + kelime) başvuru daha güçlü olabilir — vekile sorulmalı.
- **Alan adı:** `paraolcer.com` ve `paraolcer.com.tr` — boş olup olmadıkları kontrol edilmedi; [nic.tr](https://www.nic.tr/) ve bir kayıt firmasından bakılmalı. Alternatif: `paraolcer.app`, `getparaolcer.com`. Şu an veri akışı `ofzorbaci.github.io/Paraolcer` altında; kendi alan adına taşınması güveni artırır (gizlilik politikası URL'si için de gerekli).
- **Hesap adları:** X `@paraolcer`, Instagram `@paraolcer`, TikTok `@paraolcer`, YouTube `@paraolcer` — kontrol edilmedi. Ana kanal zaten kurucunun kanalı; ayrı bir uygulama hesabı sadece destek/duyuru için.
- **Karışıklık:** Mağaza aramasında "Paraölçer/paraolcer" için ilgili bir sonuç bulunmadı (açık web araması, 29.10.2026); App Store ve Google Play'de yayından önce elle tekrar bakılmalı.

### 2. Söz, slogan, ses

**Tek cümlelik söz:** "Her ay, paranın gerçekte ne kadar ettiğini — kanıtıyla — söyleriz."

**Slogan (3 seçenek):**
1. **"Paran büyüyor mu, eriyor mu? Ölç."** (önerilen — mağaza alt başlığına sığar)
2. "Nominal değil, gerçek."
3. "Birikiminin aylık karnesi."

**Ses — üç sıfat:**

| sıfat | yap | yapma |
| --- | --- | --- |
| **Dürüst** | kötü haberi açıkça söyle: "Mevduatın bu ay reel %0,8 kaybettirdi." | süsleme, "fırsatı kaçırma" dili, getiri vaadi |
| **Açık** | her rakamın kaynağını ve formülünü göster | jargonu açıklamadan bırakma ("Fisher" diyorsan bir satırda açıkla) |
| **Sakin** | panik değil ölçü: "Bu bir ölçüm, tavsiye değil." | korku pazarlaması ("paran yok oluyor!") |

**Önce/sonra (pitch'ten bir satır):**
- Önce: "Mevduatını (brüt faiz, vade, stopaj), dolar/euro, altın, fon ve hisseni gir; her birinin ve toplam birikiminin TÜFE'ye göre gerçek (reel) getirisini bugünün lirasıyla gösterir."
- Sonra: "Birikimini gir, bir dakikada gör: bugünün lirasıyla gerçekten kazandın mı, kaybettin mi — TÜFE'ye ve ENAG'a göre."

### 3. Görünüm (mevcut tema üzerinden brif)

**Renkler** (`src/constants/theme.ts`, WCAG kontrastı hesaplandı):

| renk | hex | görevi | kontrast |
| --- | --- | --- | --- |
| Gece laciverti | `#0F1B2D` | ana metin, hero kart, ikon zemini | açık zeminde (`#F4F6F9`) **15,96:1** ✓ AAA; üstünde beyaz **17,28:1** ✓ |
| Ölçü mavisi | `#1D4ED8` | vurgu, "koruyor" (pozitif) | beyaz metin üstünde **6,70:1** ✓ AA; açık zeminde **6,19:1** ✓ |
| Erime turuncusu | `#C2410C` | "eritiyor" (negatif) | açık zeminde **4,78:1** ✓ AA (normal metin), beyaz zeminde 5,18:1 ✓ |

Karanlık tema: metin `#E6EBF4` / zemin `#0A101C` 15,9:1; negatif `#FB8F5E` 8,33:1; vurgu `#6E95FF` 6,71:1 — hepsi AA üstü.

İyi bir seçim: pozitif için yeşil yerine **mavi**, negatif için kırmızı yerine **turuncu** kullanmak hem renk körlüğüne hem "borsa uygulaması" görüntüsünden uzak durmaya yarıyor. Koruyun.

**Yazı tipleri:** Sora (başlık) + Inter (metin) — ikisi de [Google Fonts](https://fonts.google.com/), SIL Open Font License, uygulamada `@expo-google-fonts` paketleriyle zaten yüklü. Lisans sorunu yok.

**Logo brifi** (seçili konsept D: kasesi gösterge kadranı olan "P"):
- Söylemesi gereken: ölçüm, doğruluk, sakinlik.
- Çalışması gereken yerler: **32 px uygulama ikonu** (kadran ibresi 32 px'de görünür kalmalı — ibreyi kalınlaştır, ince ölçek çizgilerini 48 px altında kaldır), Android tek renk (monochrome) ikon, YouTube video köşesi, X profil görseli.
- Kaçınılacaklar: yukarı ok / boğa / grafik çizgisi (yatırım uygulaması gibi görünür, getiri vaadi çağrıştırır), TL simgesi (ürün döviz/altını da ölçüyor), rakip ikonlarına benzer cüzdan şekli.

**İlk beş temas noktası:**
1. **Mağaza sayfası:** başlık "Paraölçer: Reel Getiri Karnesi", alt başlık "Paran büyüyor mu, eriyor mu? Ölç." İlk ekran görüntüsü: büyük tek sayı ("Birikimin bugünün lirasıyla: −%3,2 · ENAG: −%11") — örnek veriyle olduğu açıkça yazılı.
2. **İlk açılış (paket yerine):** kurulum yok; "Sadece mevduatını gir" tek alanı ya da "Temettü/Excel dosyamı içe aktar" — 60 saniyede ilk sonuç (kurulun şartı).
3. **Onay (deneme başlatınca):** "14 günün başladı. 12. gün sana hatırlatacağız; istersen tek dokunuşla iptal." — sürpriz ücret yok.
4. **İlk sosyal paylaşım:** lansman günü (3 Aralık, TÜFE açıklaması sonrası) gerçek kasım rakamıyla "Mevduat bu ay reel olarak %X…" görseli; altta "yatırım tavsiyesi değildir".
5. **İlk şikâyete yanıt (mağaza yorumu):** "Haklısın, [sorun]. [Tarih]'teki sürümde düzelttik / yol haritasında, [ne zaman]. Hesap yöntemi burada: [link]. — Ömer, Paraölçer" — isimle, savunmasız, tarihli.

## Operations

> **v2 (30.10.2026) — uygulamada tamamlananlar:** gizlilik sayfası, uygulama kilidi, tutarları gizleme, otomatik yedek, tüm veriyi silme, "Nasıl hesaplandı?", deneme bitiş hatırlatması, Excel/CSV içe/dışa aktarma, akışa Dünya Bankası altın ve ECB kur geçmişi. **Hâlâ açık (kurulun v2 şartları):** (1) elle fiyatlanan fon/hisse için **fiyat tarihi ve bayatlık uyarısı** skorda görünmeli; (2) **akış yedek planı** — TÜFE günü öncesi izlenen kontrol ve "veri güncelleniyor" durumu; (3) **doğrulanmış örnek hesap seti** (gerçek banka ekstreleriyle mevduat + stopaj), yöntem ekranından linkli; (4) RevenueCat `iosApiKey`/`androidApiKey` hâlâ boş; (5) stopaj oranları 31.12.2026'da bitiyor.

Tek kişilik, sunucusuz bir mobil uygulama. Günlük işin çoğu otomatik (veri akışı GitHub Actions'ta günde 2 kez çalışıyor); kurucunun işi **verinin doğruluğunu korumak, yayın yapmak ve kullanıcıya cevap vermek.**

### 1. Döngü

**Günlük (otomatik + 10 dk kontrol)**
1. 10:15 ve 14:15 (TR): `feed.yml` TCMB sayfalarını okur, doğrular, `feed.json`'u GitHub Pages'e yayımlar. *(müşteri görmez)*
2. Akış hata verirse GitHub e-postası gelir → kurucu kontrol eder. *(müşteri görmez; bozulursa uygulama "son veri: AA.YYYY" gösterir — müşteri görür)*
3. Kullanıcı uygulamayı açar → akışı okur, yoksa kayıtlı, o da yoksa gömülü kopya. Döviz (Frankfurter/ECB, yedek TCMB) ve altın (gold-api.com) telefonda çekilir. *(müşteri görür)*
4. Mağaza yorumları ve destek e-postası: 10 dk. *(müşteri görür)*

**Aylık**
5. **TÜFE günü (her ayın 3'ü civarı, TÜİK takvimine göre):** akış yeni TÜFE'yi aldı mı kontrol et; Aylık Para Karnesi bildirimi gitti mi; X/YouTube içeriği. *(müşteri görür — ürünün kalbi)*
6. TCMB Beklenti Anketi PDF'i: akışın ayrıştırdığını doğrula.
7. RevenueCat panosu: deneme, dönüşüm, iptal rakamları → `marketing.md`'deki üç rakam.

**Olay bazlı**
8. PPK karar günü: politika faizi akışta güncellendi mi; bildirim.
9. **Stopaj oranları:** `feed/withholding.json` ve `src/lib/deposit.ts` — mevcut oranlar 31.12.2026'da sona eriyor; yeni Cumhurbaşkanı Kararı çıkınca aynı gün güncellenmeli (akış süre dolmadan 30 gün önce hata veriyor — yani **1 Aralık 2026 civarı, lansmandan 2 gün önce alarm çalacak**).
10. Expo SDK / mağaza politika güncellemeleri: üç ayda bir.

### 2. Tedarikçiler (CFO'daki her kalem)

| girdi | tedarikçi | fiyat / şart | kaynak | alternatif |
| --- | --- | --- | --- | --- |
| iOS dağıtım + ödeme | Apple Developer Program | $99/yıl; Small Business Program'a ayrı başvuru gerekir (%15) | [developer.apple.com/programs](https://developer.apple.com/programs/), [Small Business Program](https://developer.apple.com/app-store/small-business-program/) | — |
| Android dağıtım + ödeme | Google Play Console | $25 tek sefer; abonelikte %15 | [play.google.com/console](https://play.google.com/console/) | — |
| Abonelik altyapısı | RevenueCat | belli gelir eşiğine kadar ücretsiz (güncel eşik kontrol edilmeli) | [revenuecat.com/pricing](https://www.revenuecat.com/pricing/) | Adapty, Qonversion; ya da doğrudan StoreKit/Billing |
| Derleme/yayın | Expo EAS | ücretsiz katmanda aylık sınırlı derleme; gerekirse ücretli | [expo.dev/pricing](https://expo.dev/pricing) | yerel derleme |
| Veri akışı barındırma | GitHub Actions + Pages | açık repo için ücretsiz | [docs.github.com](https://docs.github.com/en/billing) | Cloudflare Pages |
| TÜFE, faiz, PPK, beklenti | TCMB (EVDS / sayfalar) | ücretsiz, resmi | [evds2.tcmb.gov.tr](https://evds2.tcmb.gov.tr/) — sayfa ayrıştırma yerine **EVDS API** daha dayanıklı | TÜİK |
| Döviz | Frankfurter (ECB), yedek TCMB today.xml | ücretsiz | [frankfurter.app](https://www.frankfurter.app/) | — |
| Altın | gold-api.com | ücretsiz katman, kullanım şartları kontrol edilmeli | [gold-api.com](https://gold-api.com/) | kendi akışına TCMB/borsa kaynağı |
| ENAG | ENAG yayınları | kullanıcı girer / kurucu aylık girer — **yeniden kullanım izni kontrol edilmeli** | — | — |
| Fon fiyatları (gelecek) | TEFAS | **kullanım şartları ve izin için teklif/başvuru gerekir** | [tefas.gov.tr](https://www.tefas.gov.tr/) | lisanslı veri sağlayıcı |
| BIST fiyatları (gelecek) | Borsa İstanbul veri dağıtımı / lisanslı satıcı | **teklif gerekir**; gecikmeli veri bile lisanslı | [borsaistanbul.com veri](https://www.borsaistanbul.com/tr/sayfa/2213/veri-yayin-hizmetleri) | — |
| Alan adı | nic.tr / kayıt firması | ₺50/ay tahmin | [nic.tr](https://www.nic.tr/) | — |

CFO fiyatları değişmedi; `numbers.json` güncellenmedi. Açık soru: TEFAS/BIST verisinin maliyeti (teklif yok) → kurulun şartı, gelecekte CFO'ya eklenecek.

### 3. İnsanlar

Tek kişi: kurucu, tam zamanlı bir işin yanında. Ücret yok (CFO'da kurucu zamanı bedava sayıldı).

| gün | iş | süre |
| --- | --- | --- |
| Her gün | akış/hata e-postası, yorumlar, destek | 10–15 dk |
| Cumartesi | ana video (zaten yapılıyor) + uygulama bölümü | +30 dk |
| Pazar | Haftalık Piyasa Analizi (zaten) + 15 sn uygulama | +10 dk |
| Ayın 3'ü (TÜFE) | kontrol + X + Investing | 1 saat |
| Akşam, haftada 2 | geliştirme (Claude Code ile) | 2 × 2 saat |
| **Toplam** | | **≈ 6–7 saat/hafta** |

İlk ay (lansman): haftada ≈ 12 saat (hata düzeltme, yorum yanıtları). Yardım gerekirse ilk alınacak kişi: destek/yorum yanıtı için yarı zamanlı biri — ücret ve SGK maliyeti mali müşavire sorulmalı.

### 4. Rutinler

**A. TÜFE günü (her ay)**
1. 10:00 TÜİK açıklamasını oku; rakamı not et.
2. 10:15 akış çalıştı mı? GitHub Actions'ta yeşil mi, `feed.json`'da yeni ay var mı?
3. Uygulamayı aç: Özet ekranında "son veri" yeni ayı gösteriyor mu? Bir örnek mevduatın reel getirisini elle (Excel) doğrula.
4. Aylık Para Karnesi bildiriminin tetiklendiğini test cihazında gör.
5. X: tek tweet, gerçek rakam, "yatırım tavsiyesi değildir".
6. Sorun varsa: uygulamada banner ("bu ayın verisi gecikti") — yanlış rakam asla gösterilmez.

**B. Yeni sürüm yayını**
1. `npx tsc --noEmit`, `npx expo lint`, `vitest` hepsi geçmeli.
2. **Yedekleme/geri yükleme testi:** eski sürümde veri gir → yeni sürüme güncelle → veriler duruyor mu? (Cüzdan'ın en büyük şikâyeti bu.)
3. EAS build → TestFlight / Play iç test → 1 gün kendi telefonunda.
4. Yayın notu: ne değişti, sade dil.

**C. Şikâyet / kötü yorum**
1. 24 saat içinde, isimle yanıt (`brand.md` temas noktası 5).
2. Rakam hatasıysa: yeniden üret, yöntem sayfasıyla karşılaştır, gerçekse bugün düzelt ve yorumda tarih ver.
3. İade istenirse: iadenin mağaza (Apple/Google) üzerinden yapıldığını nazikçe ve linkiyle söyle.

**D. Veri akışı hatası**
1. GitHub e-postası → hangi kaynak? (TCMB sayfa yapısı değiştiyse ayrıştırıcı.)
2. Uygulama zaten yedek veriyle çalışır; ekranda tarih görünür.
3. Düzelt, testleri çalıştır, akışı elle tetikle.

**E. Haftalık (Pazartesi, 15 dk)**
1. RevenueCat: deneme, ücretli, iptal.
2. Mağaza: puan, yeni yorumlar.
3. Yol haritasında en çok istenen 1 şey.

### 5. Araçlar

| ihtiyaç | araç | fiyat | neden |
| --- | --- | --- | --- |
| Ödeme / abonelik | App Store + Google Play + RevenueCat | komisyon %15; RevenueCat eşik altı ücretsiz | zaten entegre |
| Analitik | App Store Connect + Play Console + RevenueCat | ücretsiz | hesapsız/gizlilik kararıyla uyumlu; üçüncü taraf takip SDK'sı eklenmez |
| Hata takibi | Sentry (ücretsiz katman) — **opsiyonel** | ücretsiz katman | eklenirse gizlilik politikasında belirtilmeli |
| Destek | tek e-posta adresi (ör. destek@paraolcer…) | alan adıyla | basit |
| Muhasebe | mali müşavir (20/B istisnası ya da şahıs şirketi) | teklif | aşağıda |

### 6. Lisans, izin, vergi — kontrol listesi

Kurallar yere göre değişir ve güncellenir; her madde ilgili kurum ya da bir profesyonelle teyit edilmeli. Hukuki/vergi tavsiyesi değil.

- [ ] **Vergi yapısı:** GVK 20/B "sosyal içerik üreticiliği ve mobil uygulama geliştiriciliği" istisnası (banka üzerinden stopajla, yıllık tutar sınırı) mı, şahıs şirketi mi? → [GİB](https://www.gib.gov.tr/) + mali müşavir. Kurucunun YouTube geliri de aynı istisnayı kullanıyorsa sınır birlikte hesaplanır.
- [ ] **Apple/Google vergi ve banka bilgileri**, Small Business Program başvurusu.
- [x] **Gizlilik politikası URL'si:** `app.json` → `legal.privacyUrl` = `ofzorbaci.github.io/Paraolcer/gizlilik.html` (yayında, veri sorumlusu adı eklendi). Kendi alan adına taşınması önerilir. Veri cihazda kalıyor, ama kur/altın/akış istekleri ve RevenueCat (satın alma kimliği) anlatılmalı.
- [ ] **KVKK:** sunucuda kişisel veri tutulmuyor; yine de aydınlatma metni gerekir mi, VERBİS kaydı gerekir mi → [kvkk.gov.tr](https://www.kvkk.gov.tr/) / avukat.
- [ ] **Kullanım şartları:** şu an Apple'ın standart EULA'sı linkli; yeterli olabilir, Google için de bir şart sayfası.
- [ ] **SPK / yatırım tavsiyesi:** uygulama ölçüm yapar, tavsiye vermez; "yatırım tavsiyesi değildir" her ekranda (mimaride var). "Yenilesem mi?" karşılaştırması **öneri cümlesi kurmamalı** ("şunu yap" değil, "geçmişte şu olurdu"). → SPK mevzuatı için uzman görüşü. Kurucu SPL sürecinde olduğu için kendi lisans kurallarını da kontrol etmeli.
- [ ] **Veri kaynaklarının kullanım şartları:** TCMB (EVDS), gold-api.com, ENAG rakamlarının uygulamada gösterilmesi.
- [ ] **RevenueCat anahtarları:** `iosApiKey` ve `androidApiKey` şu an **boş**; test anahtarı sürümde çökme yapar (kod bunu engelliyor). Yayından önce doldurulmalı.
- [ ] **Marka başvurusu** → `brand.md`.

### 7. Risk kaydı

| # | risk | olasılık | etki | plan |
| --- | --- | --- | --- | --- |
| 1 | TCMB sayfa yapısı değişir, TÜFE gelmez | orta | yüksek | yedek veri + tarih etiketi; EVDS API'ye geçiş; TÜFE günü rutini A |
| 2 | Stopaj oranları 31.12.2026'da biter, yeni karar gecikir | yüksek | yüksek | akış 30 gün önce uyarıyor; karar çıkana kadar ekranda "oranlar teyit bekliyor" |
| 3 | Güncellemede kullanıcı verisi silinir | düşük | çok yüksek | rutin B adım 2; otomatik yedek uygulamada var (`auto-backup.ts`) |
| 4 | Yanlış hesap → güven kaybı / kötü yorum | orta | yüksek | vitest testleri, aylık elle doğrulama, açık yöntem sayfası, rutin C |
| 5 | Mağaza reddi (gizlilik URL'si, finans içeriği, abonelik metni) | orta | orta | lansmandan **en az 2 hafta önce** inceleme gönder; eksikler listede |
| 6 | Bistify ya da bir banka "reel getiri"yi ekler | orta | orta | mevduat/stopaj derinliği, kanal ölçütü, hız |
| 7 | Dönüşüm çok düşük (<%1) | orta | yüksek | fiyat testi B, "Yenilesem mi?" tadımlığı, ömür boyu planı genişlet ya da projeyi yan ürün olarak tut |
| 8 | Kurucunun zamanı biter (iş + kanal + SPL) | yüksek | orta | haftalık 6–7 saat sınırı; otomasyon; yeni özellik yerine bakım önceliği |
| 9 | Ücretsiz döviz/altın API'si kapanır ya da sınırlar | düşük | orta | ikinci kaynak (TCMB) zaten var; altın için yedek kaynak ekle |
| 10 | Mevzuat: "yatırım danışmanlığı" olarak yorumlanma | düşük | yüksek | öneri dili yok, her ekranda uyarı, uzman görüşü |

## Launch plan

> **v2 (30.10.2026):** Geri sayımda tamamlananlar işaretlendi. Kritik yol değişmedi: geliştirici hesapları → abonelik ürünleri + RevenueCat anahtarları → **19 Kasım mağaza incelemesi** → 3 Aralık. Gizlilik URL'si artık kritik yolda değil.

**Hedef lansman: Perşembe 3 Aralık 2026, kasım TÜFE'sinin açıklandığı gün.** Bugün 29 Ekim 2026 → 5 hafta. Mağaza incelemesi ve eksik ayarlar (`ops.md`) için en erken gerçekçi tarih bu; kaçarsa bir sonraki doğal tarih **5 Ocak 2027 civarı (aralık TÜFE'si)**, ama o zaman Temettü penceresi (1 Ocak) kaçar.

### 1. Para harcamadan önce test

Abonelik ürünü → **Kurucu Üye teklifi, ön ödemeli.** Mağazalar aboneliği lansmandan önce tahsil etmediği için test iki adımlı:

**Adım A — Fiyatlı bekleme listesi (21 Kasım – 2 Aralık):**
- Tek sayfa (Tally/Google Forms, ücretsiz): ürünün tek cümlesi, ekran görüntüleri, **fiyat açıkça yazılı** (Kurucu Üye yıllık ₺299,99 / ömür boyu ₺999 / normal ₺49,99–₺399,99), "Lansman günü bana haber ver" + "Hangi planı alırdın?" sorusu.
- Trafik: 21 Kasım ana videosu, Haftalık Analiz, X.
- **Başarı çizgisi (önceden yazıldı):** **12 günde ≥ 1.000 kayıt** ve kayıtların **≥ %15'i** "Kurucu Üye yıllık/ömür boyu alırım" işaretlesin.

**Adım B — Gerçek ödeme (3 – 20 Aralık):**
- Kurucu Üye planları mağazada; 14 gün deneme.
- **Başarı çizgisi:** **20 Aralık'a kadar ≥ 50 ödeyen Kurucu Üye** (deneme bitip ücretli kalan ya da ömür boyu alan). CFO rampası ilk ay 30, ikinci ay 50 abone varsayıyor — bu çizgi rampanın tutup tutmadığını ilk iki haftada gösterir.

**Panelle karşılaştırma:** panel (v2) %10 alıcı dedi; bu simüle bir üst sınır. Gerçek "indirenlerin ücretliye dönüşümü" **%2'nin altında** kalırsa gerçek alıcılara güven → `/founder-offer` (ücretsiz/Premium sınırı) ya da `/founder-pricing` (test B: ₺39,99/₺299,99).

### 2. Geri sayım

Sahip: aksi yazmadıkça **Ömer**. ⚠️ = kritik yol (kayarsa lansman tarihi kayar).

#### Hafta 1 — 30 Ekim – 5 Kasım: hesaplar ve hukuk
- ⚠️ Apple Developer Program kaydı (bireysel) + Small Business Program başvurusu — 2 Kasım
- ⚠️ Google Play Console kaydı ($25) + kimlik doğrulama — 2 Kasım
- Vergi yapısı için mali müşavir görüşmesi (20/B ya da şahıs şirketi) — 5 Kasım
- Alan adı kontrolü ve kaydı (`brand.md`) — 3 Kasım
- TÜRKPATENT ön araştırma; vekile soru — 5 Kasım

#### Hafta 2 — 6 – 12 Kasım: ürünün eksikleri
- ✓ Gizlilik politikası sayfası yayında (GitHub Pages); kendi alan adına taşıma — 9 Kasım
- ⚠️ Mağazalarda abonelik ürünleri: aylık ₺49,99, yıllık ₺399,99, Kurucu Üye yıllık ₺299,99, ömür boyu ₺999; RevenueCat'te offering + `iosApiKey`/`androidApiKey` — 12 Kasım
- ✓ Sınırsız ücretsiz varlık, ENAG toplam satırı, ayda 1 "Yenilesem mi?" (uygulamada). Yeni: ücretsiz "Yenilesem mi?"yi sıralamaya indir, lira farkı Premium; paywall'da döviz/altın vitrini; ömür boyu ₺599 ürünü — 12 Kasım
- Deneme süresini mağazada 14 güne ayarla (hatırlatma uygulamada hazır) — 12 Kasım
- **Bayatlık uyarısı:** elle fiyatlanan varlıkta fiyat tarihi + skorda işaret (kurul şartı) — 12 Kasım

#### Hafta 3 — 13 – 19 Kasım: içe aktarma, kalite, inceleme
- ✓ Excel/CSV içe aktarma hazır. Temettü dışa aktarma dosyasını gerçek bir dosyayla dene (biçim farklıysa küçük bir eşleme) — 17 Kasım
- ✓ "Nasıl hesaplandı?" hazır. Ekle: gerçek banka ekstreleriyle doğrulanmış 5 örnek hesap — 17 Kasım
- Rutin B tam test: güncellemede veri korunuyor mu, yedek/geri yükleme yeni telefonda çalışıyor mu — 18 Kasım
- ⚠️ **Mağaza incelemesine gönder (iOS + Android)** — **19 Kasım** (reddedilirse düzeltmek için 2 hafta pay)
- Mağaza sayfası metni ve 5 ekran görüntüsü (`brand.md` temas noktası 1) — 19 Kasım
- Bekleme listesi sayfası hazır — 19 Kasım
- Pazarlama takvimi başlıyor: X teaser — 19 Kasım (`marketing.md`)

#### Hafta 4 — 20 – 26 Kasım: test A ve yumuşak açılış
- 21 Kasım ana video + bekleme listesi (test A başlar)
- **Yumuşak açılış:** TestFlight + Play kapalı test, 20–30 kişi (aile, arkadaşlar, kanaldan gönüllüler) — 22–29 Kasım. Soru: ilk 60 saniyede sonuç görebildiler mi? Hangi rakam onları şaşırttı?
- İnceleme geri bildirimleri düzeltilir — 26 Kasım

#### Hafta 5 — 27 Kasım – 3 Aralık: son hafta
- 28 Kasım ana video (maaş hesabı)
- ⚠️ **Stopaj oranı kararı:** akış ~1 Aralık'ta 30 gün uyarısı verecek. Yeni karar çıkmadıysa ekranda "31.12.2026 sonrası oranlar teyit bekliyor" uyarısı hazır — 1 Aralık
- Uygulama "Yayına hazır", yayın tarihi elle 3 Aralık 10:30 — 1 Aralık
- Test A sonucu: başarı çizgisi tuttu mu? Tutmadıysa fiyat B'ye geç (offering değişikliği, kod değil) — 2 Aralık
- Lansman günü X/Investing metinleri taslak (rakam boş) — 2 Aralık

**Kritik yol:** geliştirici hesapları → abonelik ürünleri + gizlilik URL'si → mağaza incelemesi (19 Kasım) → yayın. Bunlardan biri 1 haftadan fazla kayarsa lansman 5 Ocak'a kayar.

### 3. Lansman günü — Perşembe 3 Aralık 2026

| saat | ne | nerede |
| --- | --- | --- |
| 08:30 | Akış ve uygulama son kontrol; test cihazında satın alma (sandbox) | GitHub, telefon |
| 10:00 | TÜİK kasım TÜFE açıklaması | — |
| 10:15 | Akış çalıştı mı, yeni ay var mı? (Rutin A) — **gerekirse akışı elle tetikle** | GitHub Actions |
| 10:30 | Uygulama mağazada yayında (elle yayın) | App Store Connect, Play Console |
| 10:45 | Mevduat/dolar/altın kasım reel getirisini uygulamada ve Excel'de doğrula | — |
| 11:00 | X: tek tweet, gerçek rakam + mağaza linkleri + "yatırım tavsiyesi değildir" | X |
| 11:15 | Bekleme listesine "Yayındayız" mesajı, Kurucu Üye 31 Ocak'a kadar | e-posta |
| 12:00 | Investing Türkiye kısa yazı | Investing |
| 13:00–18:00 | Her saat: çökme raporu, mağaza yorumları, RevenueCat satın almaları | konsollar |
| 14:15 | İkinci akış çalışması kontrol | GitHub |
| 21:00 | Gün sonu notu: indirme, deneme, sorunlar | kendine |

**Bir şey bozulursa** (`ops.md` risk kaydı):
- TÜFE akışa gelmedi → elle tetikle; olmadıysa uygulama ekim verisiyle "son veri: 10.2026" etiketiyle açılır, tweet'teki rakam elle hesaplanır.
- Mağaza onayı gelmedi → lansman tweet'i "bekleme listesi" olarak çıkar, video Cumartesi'ye sabit kalır.
- Satın alma çalışmıyor → RevenueCat durumu; çözülene kadar paywall "yakında" moduna alınır, ücretsiz katman çalışmaya devam eder.
- Yanlış rakam bildirildi → Rutin C, aynı gün düzeltme sürümü.

### 4. İlk 30 gün (3 Aralık – 2 Ocak)

**Haftalık rakamlar:**

| rakam | kaynak | hedef (CFO/pazarlama) | değişiklik eşiği |
| --- | --- | --- | --- |
| Ödeyen abone | RevenueCat | 1. ay 30, 2. ay 50 (`numbers.json` rampası) | 2. hafta sonunda < 15 → teklif/fiyat |
| Başabaş | `cfo.md` | 17 abone (reklamsız, v2 plan) / 87 (₺2.000 reklamla) | — |
| Video başına indirme | mağaza kampanya linkleri | ≥ 300 / ana video | < 300 → hook ve çağrı |
| Deneme başlatma | RevenueCat | ≥ %8 indirenlerin | < %8 → paywall, tadımlık |
| Deneme → ücretli | RevenueCat | ≥ %30 | < %30 → ilk karne denemede geliyor mu? |
| Mağaza puanı | konsollar | ≥ 4,5, ilk 30 günde ≥ 50 yorum | < 4,0 → en sık şikâyet bu hafta düzeltilir |

**Gözden geçirmeler:**
- **7. gün (10 Aralık):** İndirmeler videolardan mı X'ten mi? İlk 60 saniyede sonuç görülüyor mu (yumuşak açılış + yorumlar)? Çökme var mı?
- **14. gün (17 Aralık):** İlk denemeler bitiyor — kaçı ücretli kaldı? Test B (₺39,99/₺299,99) başlatılsın mı? PPK haftası içeriği.
- **30. gün (2 Ocak):** Ödeyen abone rampanın neresinde? Temettü kapandı — taşıma özelliği kullanıldı mı? Ücretli reklam (₺2.000/ay) 60. günde açılsın mı, yoksa kanal tek başına yeterli mi? Ocak TÜFE günü (≈5 Ocak) ikinci "karne" anı.

_The panel is simulated buyers and the numbers are projections from your inputs. Confirm demand with real customers and costs with real quotes before you spend. Not financial, legal or tax advice._
