# Buyer panel: Paraölçer, a Turkish mobile app that shows whether your savings beat inflation

**2 buy · 48 pass** (4% buy) out of 50 simulated buyers. Seed 245730, so the same cards can be dealt again.

These are simulated buyers, not customers. Use this to find objections and weak spots, then confirm the big ones with real people before you spend.

## By segment

| group | buyers | buy rate |
| --- | ---: | ---: |
| Fund and BIST stock investor (income in TRY) | 10 | 10% |
| Salaried deposit saver (income in TRY) | 20 | 5% |
| Finance enthusiast who watches market YouTube channels (income in TRY) | 5 | 0%  (thin) |
| Holds USD/EUR and gold (income in TRY) | 15 | 0% |

## By buying behaviour

| group | buyers | buy rate |
| --- | ---: | ---: |
| Pays for useful tools | 6 | 17%  (thin) |
| Distrusts official inflation | 6 | 17%  (thin) |
| Reads every review | 4 | 0%  (thin) |
| Free-app only | 11 | 0% |
| Bank app is enough | 8 | 0% |
| Already uses a portfolio app | 4 | 0%  (thin) |
| Spreadsheet keeper | 6 | 0%  (thin) |
| Follows a finance YouTuber | 5 | 0%  (thin) |

## By income

| group | buyers | buy rate |
| --- | ---: | ---: |
| $1,188,000 and up | 17 | 6% |
| $875,000 to $1,188,000 | 17 | 6% |
| under $875,000 | 16 | 0% |

## Why they pass

| reason | buyers | in their words |
| --- | ---: | --- |
| habit | 22 | "I'd download it after the Sunday video and use the free tier, since the free version already shows my deposit's real return against TÜFE, which is all I really want to know. I never pay for app subscriptions, and alarms and charts aren't going to change that." (P003) · "I check my dollars, euros and gold in my bank app and that is enough for me. If I get curious about inflation I can open a free calculator, or just use the free version of this. I don't see what I would pay for." (P004) |
| need | 17 | "I'd download it and use the free tier, but I only roll one 32-day deposit a month, and the free version already gives me one 'Yenilesem mi?' a month plus the real-return view. That covers what I actually do, so I don't see what premium adds for me." (P001) · "I'd download the free version, because a line showing my deposit against ENAG is exactly what I want, and the free monthly 'Yenilesem mi?' already covers my one 32-day renewal. I don't see why I'd pay ₺49,99 a month for more charts and alarms on a deposit I renew the same way every month anyway." (P005) |
| trust | 3 | "It's a brand-new app with no store ratings or comments yet, and I don't pay for anything I can't read reviews on first. The free version already shows my deposit against TÜFE and ENAG, which is mostly what I want, so I'd install that and wait." (P002) · "It's a brand-new app with no store ratings or comments yet, and I don't pay for anything before I've read what other people say. I'd maybe try the free version to see my deposits and gold against inflation, but I don't see why I'd need Premium on top of that." (P015) |
| price | 3 | "I never pay for app subscriptions. The free tier already shows my deposit's real return against TÜFE and ENAG and gives me a monthly 'Yenilesem mi?', and that covers my one 32-day deposit. I'd download it, use the free part, and never upgrade." (P027) · "The free version already tells me what I need: whether my 32-day deposit beats TÜFE, and it gives me one 'Yenilesem mi?' a month, which is exactly how often I renew. I'd download it and use the free tier, but I'm not paying monthly for another app." (P045) |
| convenience | 3 | "I'd maybe download the free version and enter my money market fund once to see the real-return number, but my holdings are mostly funds and BIST stocks, and I'd have to type in their prices myself. That's exactly the chore I don't pay to take on, so I wouldn't upgrade to Premium." (P028) · "Para sorun değil, ₺50 benim için hiçbir şey; ama portföyüm fon ve BIST hissesi ağırlıklı ve fiyatları elle girmem gerekiyorsa bunu iki hafta sonra bırakırım. ENAG satırı için ücretsiz sürümü indirip bakarım, Bistify'ı bırakıp premium'a geçmem." (P033) |

## Why they buy

| reason | buyers | in their words |
| --- | ---: | --- |
| need | 2 | "I don't believe TÜİK's number, so a personal inflation basket and ENAG on every asset is exactly what I'd want to see against my 32-day deposit. I'd try the 14 days and, if my own inflation number looks believable, take the ₺299,99 founder annual since it's cheaper than one dinner out." (P016) · "I already don't believe TÜİK, and a personal inflation basket plus ENAG for every asset is exactly the check I do in my head after every raise. Data stays on my phone with no account, so I'd do the 14-day trial and take the founder yearly at ₺299,99 if the numbers hold up. That's pocket change for me." (P041) |

## What would flip a no

- If after the 14-day trial the renewal reminder plus the dollar/gold/deposit comparison actually changed one of my renewal decisions in a way I can measure in lira, the Kurucu Üye yearly ₺299,99 would be an easy yes.
- A few months of solid store ratings and real user comments saying the numbers hold up, especially the personal inflation calculation.
- If it pulled my balances straight from my bank so I didn't have to type anything, and it clearly told me something my bank app doesn't, like my real return in TL on my FX and gold.
- If the personal inflation basket gave me a real number I trust more than both TÜİK and ENAG for my own spending, I'd pay the ₺299,99 founder annual price. That's about ₺25 a month, which feels fair.
- If fund and BIST stock prices updated automatically, so I didn't have to enter them myself, I might pay a one-time lifetime price. I'd never pay a monthly subscription.
- If it pulled my fund and deposit data automatically from my bank so I didn't have to enter anything, and showed my own real inflation per asset, the lifetime ₺999 might tempt me.
- If the free version stopped covering my monthly renewal check, or if Premium showed me a concrete better deposit or renewal choice that clearly earns more than the subscription costs.
- If after the free trial its 'Yenilesem mi?' and alarms actually showed me something my spreadsheet misses, like my real return dropping below zero before I noticed, I'd consider the founder annual price.
- If the maturity reminder and the 'Yenilesem mi?' check actually got me a better rate when my deposit rolled over, so the app paid for itself on one renewal, I'd take the ₺299,99 founder annual.
- If the deposit renewal reminder and 'Yenilesem mi?' clearly earned me more interest than the subscription costs, or showed me a better rate, I might think about the cheap yearly plan.
- If the lifetime ₺999 offer were still open after I'd used the free version for a couple of months and found myself wanting the alerts and the dollar/gold comparisons, I'd pay once. I would not take a monthly plan.
- Seeing a few hundred real reviews at 4.5+ stars after a few months, plus the free tier actually saving me money on a deposit renewal decision, so the 'Yenilesem mi?' feature proves its worth before I pay.

Buyers say they would buy **1.0 times** in the first month on average.

50 buyers gave all four price answers. Run founder-pricing's van_westendorp.py on the answers folder.
