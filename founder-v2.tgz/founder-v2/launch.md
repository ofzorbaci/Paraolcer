# Lansman — Paraölçer (v2)

> **v2 (30.10.2026):** Geri sayımda tamamlananlar işaretlendi. Kritik yol değişmedi: geliştirici hesapları → abonelik ürünleri + RevenueCat anahtarları → **19 Kasım mağaza incelemesi** → 3 Aralık. Gizlilik URL'si artık kritik yolda değil.

**Hedef lansman: Perşembe 3 Aralık 2026, kasım TÜFE'sinin açıklandığı gün.** Bugün 29 Ekim 2026 → 5 hafta. Mağaza incelemesi ve eksik ayarlar (`ops.md`) için en erken gerçekçi tarih bu; kaçarsa bir sonraki doğal tarih **5 Ocak 2027 civarı (aralık TÜFE'si)**, ama o zaman Temettü penceresi (1 Ocak) kaçar.

## 1. Para harcamadan önce test

Abonelik ürünü → **Kurucu Üye teklifi, ön ödemeli.** Mağazalar aboneliği lansmandan önce tahsil etmediği için test iki adımlı:

**Adım A — Fiyatlı bekleme listesi (21 Kasım – 2 Aralık):**
- Tek sayfa (Tally/Google Forms, ücretsiz): ürünün tek cümlesi, ekran görüntüleri, **fiyat açıkça yazılı** (Kurucu Üye yıllık ₺299,99 / ömür boyu ₺999 / normal ₺49,99–₺399,99), "Lansman günü bana haber ver" + "Hangi planı alırdın?" sorusu.
- Trafik: 21 Kasım ana videosu, Haftalık Analiz, X.
- **Başarı çizgisi (önceden yazıldı):** **12 günde ≥ 1.000 kayıt** ve kayıtların **≥ %15'i** "Kurucu Üye yıllık/ömür boyu alırım" işaretlesin.

**Adım B — Gerçek ödeme (3 – 20 Aralık):**
- Kurucu Üye planları mağazada; 14 gün deneme.
- **Başarı çizgisi:** **20 Aralık'a kadar ≥ 50 ödeyen Kurucu Üye** (deneme bitip ücretli kalan ya da ömür boyu alan). CFO rampası ilk ay 30, ikinci ay 50 abone varsayıyor — bu çizgi rampanın tutup tutmadığını ilk iki haftada gösterir.

**Panelle karşılaştırma:** panel (v2) %10 alıcı dedi; bu simüle bir üst sınır. Gerçek "indirenlerin ücretliye dönüşümü" **%2'nin altında** kalırsa gerçek alıcılara güven → `/founder-offer` (ücretsiz/Premium sınırı) ya da `/founder-pricing` (test B: ₺39,99/₺299,99).

## 2. Geri sayım

Sahip: aksi yazmadıkça **Ömer**. ⚠️ = kritik yol (kayarsa lansman tarihi kayar).

### Hafta 1 — 30 Ekim – 5 Kasım: hesaplar ve hukuk
- ⚠️ Apple Developer Program kaydı (bireysel) + Small Business Program başvurusu — 2 Kasım
- ⚠️ Google Play Console kaydı ($25) + kimlik doğrulama — 2 Kasım
- Vergi yapısı için mali müşavir görüşmesi (20/B ya da şahıs şirketi) — 5 Kasım
- Alan adı kontrolü ve kaydı (`brand.md`) — 3 Kasım
- TÜRKPATENT ön araştırma; vekile soru — 5 Kasım

### Hafta 2 — 6 – 12 Kasım: ürünün eksikleri
- ✓ Gizlilik politikası sayfası yayında (GitHub Pages); kendi alan adına taşıma — 9 Kasım
- ⚠️ Mağazalarda abonelik ürünleri: aylık ₺49,99, yıllık ₺399,99, Kurucu Üye yıllık ₺299,99, ömür boyu ₺999; RevenueCat'te offering + `iosApiKey`/`androidApiKey` — 12 Kasım
- ✓ Sınırsız ücretsiz varlık, ENAG toplam satırı, ayda 1 "Yenilesem mi?" (uygulamada). Yeni: ücretsiz "Yenilesem mi?"yi sıralamaya indir, lira farkı Premium; paywall'da döviz/altın vitrini; ömür boyu ₺599 ürünü — 12 Kasım
- Deneme süresini mağazada 14 güne ayarla (hatırlatma uygulamada hazır) — 12 Kasım
- **Bayatlık uyarısı:** elle fiyatlanan varlıkta fiyat tarihi + skorda işaret (kurul şartı) — 12 Kasım

### Hafta 3 — 13 – 19 Kasım: içe aktarma, kalite, inceleme
- ✓ Excel/CSV içe aktarma hazır. Temettü dışa aktarma dosyasını gerçek bir dosyayla dene (biçim farklıysa küçük bir eşleme) — 17 Kasım
- ✓ "Nasıl hesaplandı?" hazır. Ekle: gerçek banka ekstreleriyle doğrulanmış 5 örnek hesap — 17 Kasım
- Rutin B tam test: güncellemede veri korunuyor mu, yedek/geri yükleme yeni telefonda çalışıyor mu — 18 Kasım
- ⚠️ **Mağaza incelemesine gönder (iOS + Android)** — **19 Kasım** (reddedilirse düzeltmek için 2 hafta pay)
- Mağaza sayfası metni ve 5 ekran görüntüsü (`brand.md` temas noktası 1) — 19 Kasım
- Bekleme listesi sayfası hazır — 19 Kasım
- Pazarlama takvimi başlıyor: X teaser — 19 Kasım (`marketing.md`)

### Hafta 4 — 20 – 26 Kasım: test A ve yumuşak açılış
- 21 Kasım ana video + bekleme listesi (test A başlar)
- **Yumuşak açılış:** TestFlight + Play kapalı test, 20–30 kişi (aile, arkadaşlar, kanaldan gönüllüler) — 22–29 Kasım. Soru: ilk 60 saniyede sonuç görebildiler mi? Hangi rakam onları şaşırttı?
- İnceleme geri bildirimleri düzeltilir — 26 Kasım

### Hafta 5 — 27 Kasım – 3 Aralık: son hafta
- 28 Kasım ana video (maaş hesabı)
- ⚠️ **Stopaj oranı kararı:** akış ~1 Aralık'ta 30 gün uyarısı verecek. Yeni karar çıkmadıysa ekranda "31.12.2026 sonrası oranlar teyit bekliyor" uyarısı hazır — 1 Aralık
- Uygulama "Yayına hazır", yayın tarihi elle 3 Aralık 10:30 — 1 Aralık
- Test A sonucu: başarı çizgisi tuttu mu? Tutmadıysa fiyat B'ye geç (offering değişikliği, kod değil) — 2 Aralık
- Lansman günü X/Investing metinleri taslak (rakam boş) — 2 Aralık

**Kritik yol:** geliştirici hesapları → abonelik ürünleri + gizlilik URL'si → mağaza incelemesi (19 Kasım) → yayın. Bunlardan biri 1 haftadan fazla kayarsa lansman 5 Ocak'a kayar.

## 3. Lansman günü — Perşembe 3 Aralık 2026

| saat | ne | nerede |
| --- | --- | --- |
| 08:30 | Akış ve uygulama son kontrol; test cihazında satın alma (sandbox) | GitHub, telefon |
| 10:00 | TÜİK kasım TÜFE açıklaması | — |
| 10:15 | Akış çalıştı mı, yeni ay var mı? (Rutin A) — **gerekirse akışı elle tetikle** | GitHub Actions |
| 10:30 | Uygulama mağazada yayında (elle yayın) | App Store Connect, Play Console |
| 10:45 | Mevduat/dolar/altın kasım reel getirisini uygulamada ve Excel'de doğrula | — |
| 11:00 | X: tek tweet, gerçek rakam + mağaza linkleri + "yatırım tavsiyesi değildir" | X |
| 11:15 | Bekleme listesine "Yayındayız" mesajı, Kurucu Üye 31 Ocak'a kadar | e-posta |
| 12:00 | Investing Türkiye kısa yazı | Investing |
| 13:00–18:00 | Her saat: çökme raporu, mağaza yorumları, RevenueCat satın almaları | konsollar |
| 14:15 | İkinci akış çalışması kontrol | GitHub |
| 21:00 | Gün sonu notu: indirme, deneme, sorunlar | kendine |

**Bir şey bozulursa** (`ops.md` risk kaydı):
- TÜFE akışa gelmedi → elle tetikle; olmadıysa uygulama ekim verisiyle "son veri: 10.2026" etiketiyle açılır, tweet'teki rakam elle hesaplanır.
- Mağaza onayı gelmedi → lansman tweet'i "bekleme listesi" olarak çıkar, video Cumartesi'ye sabit kalır.
- Satın alma çalışmıyor → RevenueCat durumu; çözülene kadar paywall "yakında" moduna alınır, ücretsiz katman çalışmaya devam eder.
- Yanlış rakam bildirildi → Rutin C, aynı gün düzeltme sürümü.

## 4. İlk 30 gün (3 Aralık – 2 Ocak)

**Haftalık rakamlar:**

| rakam | kaynak | hedef (CFO/pazarlama) | değişiklik eşiği |
| --- | --- | --- | --- |
| Ödeyen abone | RevenueCat | 1. ay 30, 2. ay 50 (`numbers.json` rampası) | 2. hafta sonunda < 15 → teklif/fiyat |
| Başabaş | `cfo.md` | 17 abone (reklamsız, v2 plan) / 87 (₺2.000 reklamla) | — |
| Video başına indirme | mağaza kampanya linkleri | ≥ 300 / ana video | < 300 → hook ve çağrı |
| Deneme başlatma | RevenueCat | ≥ %8 indirenlerin | < %8 → paywall, tadımlık |
| Deneme → ücretli | RevenueCat | ≥ %30 | < %30 → ilk karne denemede geliyor mu? |
| Mağaza puanı | konsollar | ≥ 4,5, ilk 30 günde ≥ 50 yorum | < 4,0 → en sık şikâyet bu hafta düzeltilir |

**Gözden geçirmeler:**
- **7. gün (10 Aralık):** İndirmeler videolardan mı X'ten mi? İlk 60 saniyede sonuç görülüyor mu (yumuşak açılış + yorumlar)? Çökme var mı?
- **14. gün (17 Aralık):** İlk denemeler bitiyor — kaçı ücretli kaldı? Test B (₺39,99/₺299,99) başlatılsın mı? PPK haftası içeriği.
- **30. gün (2 Ocak):** Ödeyen abone rampanın neresinde? Temettü kapandı — taşıma özelliği kullanıldı mı? Ücretli reklam (₺2.000/ay) 60. günde açılsın mı, yoksa kanal tek başına yeterli mi? Ocak TÜFE günü (≈5 Ocak) ikinci "karne" anı.
