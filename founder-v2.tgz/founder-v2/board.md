# Yönetim Kurulu — Paraölçer (v2, 30.10.2026)

**Oy: 3 × FUND IF (şartlı fonla)** · Ortalama puan: **5,7 / 10** (Teklif 6, Tekel 5, Ürün 6) — v1: 5,3 (6 / 4 / 6).

Kurul üyeleri yayımlanmış çerçeveleri uygular; o kişiler değildir. Memolar: `board/offers.md`, `board/monopoly.md`, `board/product.md`.

**Ne değişti:** Tekel merceği 4 → 5: dar segment ("vade yenileyen, TÜFE'ye güvenmeyen mevduatçı"), Temettü'nün kapanışı ve hesapsız gizlilik artık bir konumlanma kaması. Ürün merceği ilk 60 saniyenin, yöntem ekranının ve TÜFE günü karnesinin tasarlandığını kabul ediyor. v1'in üç şartı karşılandı: ilk dakikada sonuç, yöntem sayfası, yedek/geri yükleme ve kilit.

## Birden fazla üyenin işaret ettiği riskler

1. **Elle fon/hisse fiyatı hâlâ duruyor** — üçü de. Ürün: bayat fiyat "kendinden emin ama yanlış" bir skor üretir. Tekel: Bistify'ın en güçlü olduğu alan; ya otomatik fiyat ya da bilinçli olarak kapsam dışı.
2. **Premium'un satış nedeni bulanık / ücretsiz katman fazla iyi olabilir** — Teklif ve Ürün. Premium'da 10'dan fazla kalem var; "asıl ne için ödüyorum?" sorusu cevapsız. Aylık tek vade yenileyen biri ayda 1 ücretsiz "Yenilesem mi?" ile yetinebilir.
3. **Kanıt / güven** — Teklif ve Tekel. Yeni sürüm hiç test edilmedi; yorum yok, dağıtım tek kişiye (kanal) bağlı, izleyiciden ödeyene dönüşüm bilinmiyor.
4. **Kopyalanabilirlik** — Tekel: Bistify ENAG ve "yenile?" ekranını bir sürümde ekleyebilir.
5. **Veri akışının TÜFE günü bozulması** — Ürün: sunucusuz akış imza anında herkesin önünde çökebilir.

## Şartlar — kontrol listesi

- [ ] **Ön satış / gerçek ödeme testi**, başarı eşiği önceden yazılı → `/founder-launch`
- [ ] **Premium'u "Yenilesem mi?" etrafında kur**; lansmanda Premium'u çekirdeğe (sınırsız "Yenilesem mi?", varlık bazında ENAG, reel getiri alarmı) indir, gerisini kullanıma göre ekle → `/founder-offer`
- [ ] **Bayat fiyat uyarısı**: elle fiyatlanan her varlıkta fiyat tarihi + skor üzerinde bayatlık işareti; ya da lansmandan önce TEFAS için ilk otomatik kaynak → `/founder-ops`
- [ ] **Akış yedek planı**: son iyi veri, "veri güncelleniyor" durumu, TÜFE öncesi izlenen kontrol → `/founder-ops`
- [ ] **Doğrulanmış örnek hesap seti** (mevduat + stopaj, gerçek banka ekstreleriyle), "Nasıl hesaplandı?"dan linkli → `/founder-ops`
- [ ] **Garanti** (deneme + açık iptal; iade mağazada) → `/founder-offer`
- [ ] **20+ gerçek kullanıcı sonucu** (izinli, anonim) ücretli pazarlamadan önce → `/founder-launch`, `/founder-marketing`
- [ ] **Karne ritüelini kanalın sabit bölümü yap** → `/founder-marketing`
- [ ] **İlk 60 günde dağıtımı kanıtla**: video başına indirme ve deneme→ücretli, eşik önceden → `/founder-launch`
- [ ] **Fon/hisse için karar**: otomatik fiyat planı ya da bilinçli kapsam dışı → `/founder-ops`, `/founder-marketing`

## Ayrılıklar

- **Kapsam:** Ürün merceği Premium'u lansmanda daraltmak istiyor; Teklif merceği "Yenilesem mi?"yi merkeze alıp fiyatı yükseltmeyi bile düşünüyor ("iki katı fiyat isteyebilir misin?"). Tekel merceği ise fon/hisseden bilinçli olarak vazgeçmeyi öneriyor.
- **Fiyat:** Teklif merceği "en ucuz olan" algısından endişeli (₺49,99 vs Bistify ₺79,99); diğerleri fiyatı konu etmiyor.

## Kurulun görebildiği en güçlü versiyon

Paraölçer "her şeyi takip eden portföy uygulaması" olmaya çalışmaz; **vade günü kararının ve TÜFE günü karnesinin uygulaması** olur. Mevduat, döviz ve altın (fiyatı otomatik gelen varlıklar) tam doğrulukla; fon ve hisse ikinci sınıf ama dürüstçe tarih etiketli. Premium'un tek cümlesi: "Her vade gününde ve her TÜFE gününde, paranın gerçek karnesi ve geçmişte ne olurdu kıyası." Kanal her ayın TÜFE gününde aynı karneyi yayınlar; marka bu ritüelden doğar.
