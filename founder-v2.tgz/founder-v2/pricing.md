# Fiyatlama — Paraölçer (v2)

Tüm fiyatlar TL, KDV dahil. Araç çıktılarında "$" = TL.

## 1. Fiyat: aylık ₺49,99 · yıllık ₺399,99 — değişmedi

**Panel (v2, 50 simüle alıcı, aylık fiyat)** — `pricing-curve.md`:

| nokta | v1 (₺79,99 pitch) | v2 (₺49,99 pitch) |
| --- | ---: | ---: |
| PMC | ₺15,81 | ₺15,66 |
| OPP | ₺20,84 | ₺20,84 |
| IPP | ₺35,42 | ₺30,49 |
| PME | ₺69,84 | ₺60,11 |

Kabul edilebilir aralık **₺16–60/ay**. ₺49,99 **aralığın içinde** ama üst bölümde; yıllık ₺399,99 (≈ ₺33,3/ay) IPP'nin hemen üstünde. Not: alıcılar gösterilen fiyata çapalanıyor (pitch ₺79,99 iken PME ₺70, ₺49,99 iken ₺60); aralığın kendisi kesin değil.

- **Fiyat değil, ihtiyaç engel:** v2'de "price" sebebiyle geçen sadece 3 kişi; 19'u "need" (ücretsiz yetiyor), 22'si "habit" (abonelik ödemem). Fiyatı düşürmek bu iki grubu çevirmez.
- **Rakipler:** BES Enflasyon Pro ≈ ₺42/ay, Bistify Pro ₺79,99, İyi Gelir ₺559/ay. Paraölçer yıllıkta en ucuz ikinci.
- **Marj** (`cfo.md`): katkı ₺28,33 / abone-ay, %85.

## 2. Merdiven

| basamak | fiyat | kime |
| --- | --- | --- |
| Ücretsiz | ₺0 | herkes; "param eridi mi?" cevabı |
| Aylık | ₺49,99 | denemek isteyen, taahhüt istemeyen |
| **Yıllık (varsayılan)** | ₺399,99 | asıl satılan plan |
| **Ömür boyu — sadece Kurucu Üye, ilk 500** | **₺599 (öneri; şu an ₺999)** | "aboneliğe para vermem" diyen 22 kişilik grup |

**Ömür boyu fiyatı ₺999 → ₺599'a çekmeyi test et.** Panelde tek seferlik isteyenlerin söylediği aralık ₺150–400 (v1) ve ₺200–300 (v2, P045, P049); ₺999 "çok yüksek" bulundu (P049). ₺599'lu teklif re-testte iki kişide "o zaman alırım" ifadesi çıkardı (P010, P013). Ömür boyu = ≈1,5 yıllık plan; 500 adetle sınırlı olduğu için abonelik gelirini kalıcı olarak yemez.

## 3. Açılış teklifi

Kurucu Üye, lansmandan (3 Aralık 2026) **31 Ocak 2027'ye** kadar: yıllık ₺299,99 abone kaldıkça sabit; ya da ilk 500 kişiye ömür boyu ₺599. Bitiş tarihi gerçek, sahte çapa yok.

## 4. Gerçek alıcıyla test

- **A:** ₺49,99 / ₺399,99 · **B:** ₺39,99 / ₺299,99 (RevenueCat Experiments).
- **Ömür boyu:** ilk 250 kişi ₺599, sonraki 250 ₺799 — hangi hızla tükendiğine bak.
- Ölçü: 1.000 indirme başına net gelir.

## 5. Fiyat itirazları (birebir, panel v2)

1. "₺49,99 a month to confirm my deposit barely keeps up isn't worth it." (P027)
2. "Even ₺50 a month feels like a waste; I'd rather put it toward another gram of gold." (P049)
3. "A one-time purchase of about ₺200–250, much cheaper than the ₺999 lifetime offer, with no recurring charge." (P045)

Simüle cevaplar neyi test edeceğimizi seçer; kanıt değildir.
