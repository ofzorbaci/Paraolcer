# Product lens
Score: 6/10 | Vote: FUND IF

## What is strong
- **The core question fits in one sentence:** "Did my savings actually beat inflation?" That is a real, emotional moment, and the deposit-maturity "Yenilesem mi?" screen gives it a recurring use. The product has a reason to be opened every month, not just once.
- **The first five minutes have been designed.** A sample portfolio and a quick deposit card aim for a first result in under a minute, with no account. "Nasıl hesaplandı?" shows the method, which matters in a market that distrusts numbers.
- **Privacy works as part of the experience:** data stays on the phone, plus app lock, hidden amounts and delete-all. For people who doubt official numbers, that builds trust.
- **There is a ritual:** the TÜFE-day karne and a launch on CPI day turn a data release into a reason to come back and share.

## What would kill it (the top 3, most dangerous first)
1. **Manual fund and stock prices are a weak point at the heart of the product.** A real-return score is only as true as its inputs. If a user's fund price is weeks old, the app shows a confident number that is wrong, and the user blames the app. The earlier panel already flagged this, and it has not been fixed.
2. **Too many features weaken the one thing.** The free tier is broad. Premium lists more than a dozen items: scenarios, time machine, benchmarks, goals, alerts, multiple portfolios, a personal basket. Each one adds screens, edge cases and things that can break for a solo founder with a full-time job. The paid reason is also unclear: is it "unlimited Yenilesem mi?" or something else?
3. **The data pipeline has no owner at the moment it matters.** A free GitHub Pages feed, a public gold API and ECB/TCMB rates must all update correctly on TÜFE day, the app's signature moment. With no server, a late or broken feed fails in front of every user at once. One visibly wrong figure, such as a withholding-tax or compounding error, could cost the trust the brand depends on.

## The questions I would ask the founder
- If you could ship only one screen, which is it? Is that screen what Premium sells?
- What does a user see when a fund price is stale? Is there an "as of" date, a warning, or nothing?
- What happens in the app if the data feed is late on 3 December?
- How is the deposit and withholding-tax math checked against real bank statements? How many cases have you tested?
- "Automatic backup" with no account: where does the data go, and what does restoring on a new phone feel like?
- Which Premium features would you cut today if nobody noticed?

## If FUND IF: the conditions
1. Every manually priced holding shows the date of its price, and the score is visibly flagged when inputs are stale. Or ship a first automated price source for TEFAS funds before launch.
2. Cut Premium at launch to the few features tied to the core question, such as unlimited "Yenilesem mi?", per-holding ENAG/personal inflation, and the real-return alert. Add the rest later, based on usage.
3. Build a feed fallback: cached last-good data, a clear "data updating" state, and a monitored check before each TÜFE release.
4. Publish a test set of worked deposit and return examples that match the app's output, and link it from "Nasıl hesaplandı?".
