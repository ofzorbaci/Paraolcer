# Monopoly lens

Score: 5/10 | Vote: FUND IF

## What is strong

- **Distribution exists before the product.** A ~90,000-subscriber Turkish markets channel plus Investing Türkiye and X reach exactly this buyer for close to nothing. Most solo apps die because they cannot reach anyone. This one can.
- **A small market it could own first.** "Salaried TL depositors who roll over monthly and doubt TÜFE" is narrow enough to lead. No competitor in the brief builds around the maturity-day decision ("Yenilesem mi?") with ENAG and personal inflation side by side.
- **Timing.** Temettü shuts on 1 January 2027, and Cüzdan users report data loss. Launching on CPI release day, with an import path ready, gives people a reason to switch now.
- **A positioning wedge.** No account and no server, against Bistify, which needs an account. Privacy works as a brand claim in personal finance.

## What would kill it (the top 3, most dangerous first)

1. **No proprietary edge.** Real return against TÜFE is already on Bistify's chart, with automatic prices and broker imports. ENAG and a renewal calculator are features a funded competitor could ship by month six. Nothing here is ten times better at the job of tracking a portfolio.
2. **Manual fund/stock prices.** The incumbent automates the step this app still makes users type in. That moves the app toward deposit, FX and gold holders only, and caps the market it can win.
3. **Distribution tied to one person.** If the channel is the only way buyers arrive, the business is a founder-audience product, not a durable brand. Conversion from viewer to payer is unknown.

## The questions I would ask the founder

- What is the secret: what do you know about Turkish savers' renewal behaviour that Bistify does not?
- Of your ~90,000 subscribers, how many hold TL deposits they roll over monthly? (Unknown; can a community poll measure it?)
- What viewer-to-install and install-to-paid rates do you expect, and what is that based on? (Open question; there is no data yet.)
- What stops Bistify from adding ENAG and a "renew?" screen in one release?
- What builds up over time and is hard to copy: a dataset, the personal inflation baskets, the monthly TÜFE-day karne ritual, the brand?
- Ten years out, is this an app, or the trusted Turkish "real return" brand across video, app and data?

## If FUND IF: the conditions

1. **Own the narrow segment first.** Lead every message with deposit renewal and personal inflation, not general portfolio tracking. Measure the share of that niche before broadening.
2. **Make the monthly karne a ritual that is yours.** Tie it to a recurring channel segment on every TÜFE day so the brand, not the feature list, becomes the moat.
3. **Prove distribution in the first 60 days.** Publish real numbers: installs per video and conversion of trials to paid. Set the threshold in advance, before the results come in.
4. **Have a plan for automatic prices,** or state on purpose that funds and stocks are out of scope, so the app does not fight the incumbent on its strongest ground.
