# Offers lens
Score: 6/10 | Vote: FUND IF

## What is strong
- **Market.** The pain is big and easy to see: Turkish savers who roll over deposits each month and don't trust official inflation. They are easy to reach, because the founder already has ~90,000 YouTube subscribers plus Investing Türkiye and X, all aimed at this exact buyer. That brings in early users at almost no cost.
- **Dream outcome and time to result.** "Did my money really beat inflation, in today's lira?" is a sharp promise. The sample portfolio and quick deposit card give a first result in under a minute, which is very fast.
- **Effort on the core use.** No account, data stays on the phone, and Excel/CSV import is included. For savers who hold deposits, FX and gold, prices fill in automatically, so the main use takes little effort.
- **Real urgency.** The "Kurucu Üye" deadline (31 January 2027) and the cap of 500 lifetime seats are real limits, not invented ones. The launch on the CPI release day ties the offer to a moment people already care about.

## What would kill it (the top 3, most dangerous first)
1. **Weak proof that it is right.** The earlier simulated panel bought at 2%, and the product has changed since, so nobody has tested the new version. A new app with no reviews is asking people to trust its maths about their savings. The "Nasıl hesaplandı?" screen helps, but there is no guarantee, no third-party check and no visible track record.
2. **The free tier may be too good.** The free tier covers unlimited holdings, the real-return score, a one-line ENAG/personal total, a monthly "Yenilesem mi?", the karne report card and full import/export. That could cover what most deposit-rollers need. Premium's main draw (unlimited "Yenilesem mi?") matters most to the monthly roller, who may need only one result a month anyway.
3. **Being cheapest is the only clear difference.** At ₺49,99 against Bistify's ₺79,99 Pro, the offer risks reading as "the cheaper one." Bistify already shows real return vs TÜFE and fills in prices automatically. For fund/stock holders, typing prices by hand is a cost Bistify users don't pay.

## The questions I would ask the founder
- What share of your audience holds only deposits, FX and gold (no manual prices), and how many of them roll over a deposit each month? Nobody has this number yet.
- What conversion rate from free to paid do you need for this to be worth your time? It is an open question until a target is stated.
- What guarantee can you offer? For example: "if the karne doesn't change one decision in 30 days, refund."
- Could you charge twice the price if premium included something no competitor has, such as a monthly reminder at each maturity date with the real-return case worked out?
- Has anyone re-tested the changed version with buyers, simulated or real?

## If FUND IF: the conditions
1. **Pre-sell before 3 December.** Use the channel to pre-sell Kurucu Üye seats and set a minimum number of paid seats in advance (the founder picks the figure). If it isn't reached, revisit the free/premium split.
2. **Make "Yenilesem mi?" the main thing premium sells.** Show it on screen at each maturity, with a worked example. Don't let premium read as a list of charts.
3. **Add a stated guarantee,** either a refund window or a promise backed by the published method.
4. **Collect 20+ real user results or testimonials** from the channel audience before paid marketing starts, so the next buyer has proof.
