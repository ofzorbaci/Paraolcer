# CFO kaynakları

| kalem | tutar | kaynak |
| --- | --- | --- |
| Mağaza komisyonu %15 | ₺5,00 / abone-ay | Apple App Store Small Business Program ve Google Play abonelik oranı (%15); kurucunun hesabının programa kayıtlı olduğu doğrulanmalı |
| KDV %20 | fiyattan ayrıldı | Türkiye KDV oranı; App Store / Google Play TR fiyatları KDV dahil |
| RevenueCat | ₺0 | TAHMİN — belli bir gelir eşiğine kadar ücretsiz; güncel eşik revenuecat.com/pricing'den kontrol edilmeli |
| Apple Developer Program | $99/yıl → ₺411/ay | Apple'ın yayımlanmış ücreti; USD/TRY 49,8345 (TradingView FX_IDC:USDTRY, 29.10.2026) |
| Google Play kayıt | $25 → ₺1.246 tek sefer | Google'ın yayımlanmış ücreti; aynı kur |
| Alan adı + gizlilik sayfası | ₺50/ay | TAHMİN |
| Ücretli reklam | ₺0 (ilk 60 gün) | pazarlama planı; edinme maliyeti ölçülünce açılır |
| Gizlilik sayfası (yayında) + KVKK incelemesi | ₺3.000 | TAHMİN — sayfa hazır, avukat incelemesi teklif |
| Lansman reklam ve görseller | ₺10.000 | TAHMİN |
| Veri akışı (GitHub Actions + Pages) | ₺0 | mevcut kurulum (repo `.github/workflows/feed.yml`) |
| Rampa 30→250 ödeyen abone | — | TAHMİN: ~10 bin indirme × ~%2,5; panel v2 %10 (üst sınır) |
| Ödeme karışımı %60 yıllık / %40 aylık | — | TAHMİN |
