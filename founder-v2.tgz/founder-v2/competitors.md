# Rakipler — Paraölçer (v2)

Kaynak tarihi: 29.10.2026 (dün okunan sayfalar; bugün yeniden okunmadı). Sadece açık kaynaklar. Google Play arama sayfaları otomatik okumaya kapalı; Android tarafı doğrulanamadı.

## 1. Tablo (doğrudan rekabet sırasıyla)

| ad | tür | ne satıyor | reel getiri | fiyat | puan |
| --- | --- | --- | --- | --- | --- |
| [Bistify](https://bistify.net/) | doğrudan | BIST, TEFAS, BES, ABD, altın, döviz, kripto **otomatik fiyatla**; Midas PDF/Excel/BES CSV içe aktarma; FIFO K/Z; temettü; Sharpe/beta; zaman makinesi; PIN/Face ID; **hesap zorunlu** (Google/Apple) | Var — TÜFE aynı grafikte | Ücretsiz + Pro [₺79,99](https://apps.apple.com/tr/app/id6762283764) | 4,9 (15) |
| [FinAIEra](https://finaiera.com/portfoy) | doğrudan (web) | kripto/hisse/döviz, haftalık AI denetimi | Var (TÜFE/CPI) | gösterilmiyor | — |
| [BES Enflasyon Pro](https://apps.apple.com/tr/app/bes-enflasyon-pro/id6633425959) | doğrudan, sadece BES | BES vs enflasyon, ENAG varsayılan | Var (BES) | ₺299,99/6 ay · ₺499,99/yıl | 5,0 (1) |
| [İyi Gelir](https://apps.apple.com/tr/app/i-yi-gelir/id6744439314?l=tr) | dolaylı | fon analizi, alarm, hedef, notlar | Yok | ₺559/ay · ₺5.199,99/yıl | 3,9 (42) |
| [Temettü](https://apps.apple.com/tr/app/id1515109673) | dolaylı — **1 Ocak 2027'de kapanıyor** | BIST + temettü | Yok | yeni abonelik durdu | 4,6 (430) |
| [Cüzdan](https://apps.apple.com/tr/app/id6553987158) | dolaylı | altın, döviz, BIST, kripto | Yok | ücretsiz | 4,5 (78) |
| Hızlı Hesap, FVT, InvestinGoal | ikame | tek seferlik reel getiri hesaplayıcıları | Var, kayıt yok | ücretsiz | — |
| Excel / kafadan hesap | ikame | mevduat faizi vs manşet TÜFE | — | ücretsiz | — |

## 2. Fiyat aralığı (Premium, aylık eşdeğer)

- En düşük: BES Enflasyon Pro yıllık ≈ **₺42/ay**
- Orta: **Bistify Pro ₺79,99** (dönemi gösterilmiyor; aylık varsayılırsa)
- En yüksek: İyi Gelir **₺559/ay** (yıllık ≈ ₺433/ay)

## 3. Konumlandırma haritası

Eksenler: yatay = kapsam (tek hesap ↔ tüm portföy, otomatik fiyat), dikey = enflasyon/karar odağı.

```
         enflasyon + KARAR ürünün merkezi
                    ^
  BES Enflasyon     |   Paraölçer v2 (mevduat/döviz/altın tam,
  Hızlı Hesap/FVT   |   fon/hisse elle; "Yenilesem mi?", karne)
                    |
                    |            Bistify (reel getiri bir grafik,
                    |            otomatik fiyat, risk metrikleri)
 tek hesap ---------+-----------------------------> tüm portföy
                    |   FinAIEra
                    |   İyi Gelir   Cüzdan   Temettü (kapanıyor)
                    v
         enflasyon yok / yan özellik
```

## 4. Şikâyetler (değişmedi)

1. Güncellemede veri kaybı — Cüzdan, 3 yorum ([kaynak](https://apps.apple.com/tr/app/id6553987158)).
2. Fiyat çok yüksek / ani zam — İyi Gelir, 1 yorum (ince).
3. Hesap/şifre sorunu — İyi Gelir, 1 yorum (ince).
4. Eksik varlık türü (fon) — Cüzdan, 1 istek (ince).

## 5. Boşluk — v2'de ne değişti

Paraölçer v2, rakiplerin "hijyen" özelliklerinin çoğunu kapattı: Excel/CSV içe/dışa aktarma, kilit, tutarları gizleme, otomatik yedek, tüm veriyi silme, çoklu portföy, kıyas grafiği, zaman makinesi, alarm/hedef. Bistify'a karşı kalan farklar:

| | Paraölçer v2 | Bistify |
| --- | --- | --- |
| Mevduat (brüt faiz, vade, stopaj) | **Var** | yok |
| ENAG / kişisel enflasyon / kişisel sepet | **Var** | yok |
| Vade günü kararı ("Yenilesem mi?") | **Var** | yok |
| TÜFE günü karnesi + paylaşılabilir görsel | **Var** | yok |
| Hesapsız, veri telefonda | **Var** | hesap zorunlu |
| Fon/hisse otomatik fiyat | **yok (elle)** | Var |
| Midas PDF / BES CSV içe aktarma | yok | Var |
| Temettü, risk metrikleri | yok (bilinçli) | Var |

**Boşluk:** mevduat/döviz/altın tutan tasarruf sahibi için enflasyon + karar uygulaması. Fon/hisse yatırımcısı için Bistify açıkça daha iyi; Paraölçer orada rekabet etmemeli.

## 6. Tehdit

1. **Bistify** — ENAG ve "yenile?" ekranını bir sürümde ekleyebilir (Tekel merceği). Savunma: mevduat derinliği, karne ritüeli, kanal.
2. **Banka uygulamaları** — doğrulanmadı.
3. **Temettü kapanışı iki yönlü:** Temettü kullanıcıları hisse yatırımcısı; büyük kısmı Bistify'a gidecek. Paraölçer'in Temettü'ye özel bir içe aktarıcısı yok (sadece genel Excel/CSV).
