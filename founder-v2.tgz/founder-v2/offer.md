# Teklif — Paraölçer (v2)

## 1. Mevcut sürüm hangi sorunları çözdü (v1 listesinden)

| v1 sorunu | durum (uygulamada) |
| --- | --- |
| "3 varlık bana yetiyor" | ✓ limit kalktı — itiraz kayboldu |
| "TÜİK benim enflasyonum değil" / ENAG kilitli | ✓ ENAG toplam satırı ücretsiz — itiraz kayboldu, ama yeni sorun doğurdu (aşağıda) |
| İlk dakikada sonuç | ✓ hızlı mevduat kartı, örnek portföy |
| Excel'imde var / taşıma | ✓ Excel/CSV içe ve dışa aktarma (Temettü'ye özel içe aktarıcı yok) |
| Veri kaybı / güven | ✓ otomatik yedek, kilit, gizleme, tüm veriyi sil, "Nasıl hesaplandı?" |
| "Ne yapacağımı söylemiyor" | ◐ "Yenilesem mi?" var; ama geçmişe bakıyor (aşağıda) |
| Fon/hisse elle fiyat | ✗ hâlâ elle |
| Abonelik istemem | ◐ ömür boyu plan var, ₺999 yüksek bulundu |
| Yorum yok / yeni uygulama | ✗ sadece lansmanla çözülür |

## 2. Panelin v2'de söylediği yeni sorunlar

1. **"Ücretsiz zaten yetiyor"** — 19 kişi ("need"). Ayda bir vade yenileyen biri için ayda 1 ücretsiz "Yenilesem mi?" tam ihtiyacı kadar; ENAG satırı da ücretsiz.
2. **"Geriye bakıyor, bana para kazandırmıyor"** — P012, P014, P017: "Dolarda tutsaydın ₺X" geçmişin fotoğrafı; asıl soru "**şimdi hangi banka/vade enflasyonu yeniyor?**".
3. **Premium'u mevduatçıya göre kurmak döviz/altın tutanı dışarıda bırakıyor** — re-testte P013, P019, P020: "Vade Günü Paketi benim için değil."
4. **Kişisel enflasyon sepeti gerçek mi?** — P016, P020: elle girilen bir tahminse değersiz; harcamadan beslenirse değerli.
5. **Abonelik reddi** — 22 kişi "habit"; bir kısmı ₺200–600 tek seferlik ödemeye açık.

## 3. Önerilen paket (re-test edilen)

- **Çekirdek:** "Vade Günü Paketi" — her vadende hatırlatma ve "Yenilesem mi?"nin tamamı **lira olarak** ("aynı koşulla yenileseydin ₺X, dolarda ₺Y, altında ₺Z — bugünün lirasıyla"), 1/3/12 ay; varlık bazında ENAG + kişisel sepet; tam karne; reel getiri alarmı; grafikler; çoklu portföy.
- **Ücretsiz katmanda daraltma:** "Yenilesem mi?" ücretsizde sadece **sıralama** (son 1 ay, hangisi daha iyi korudu); lira farkı ve 3/12 ay Premium. Karne ücretsizde özet.
- **Ömür boyu ₺599** (ilk 500, 31 Ocak 2027'ye kadar).
- Garanti: 14 gün deneme + bitmeden hatırlatma + mağazadan tek dokunuşla iptal.

## 4. Değer denklemi (1–10)

| unsur | v1 | v2 (uygulama) | v3 (öneri) | ne değiştirdi |
| --- | ---: | ---: | ---: | --- |
| Hayal edilen sonuç | 5 | 7 | 7 | karar ekranı var; ama geçmişe dönük |
| Elde etme ihtimali (güven) | 4 | 6 | 6 | yöntem ekranı, kilit, yedek; yorum yok |
| Süre | 6 | 8 | 8 | ilk dakikada sonuç |
| Çaba | 4 | 6 | 6 | Excel içe aktarma; fon/hisse hâlâ elle |

## 5. Re-test — aynı tohum, aynı ilk 20 alıcı

| sürüm | alan | sebep dağılımı |
| --- | ---: | --- |
| v1 (₺79,99, 3 varlık) | 1/20 (P020) | need 10 · habit 8 · trust 2 |
| v1 teklif önerisi (dünkü) | 2/20 (P016, P020) | need 10 · habit 6 · trust 4 |
| **v2 = şu anki uygulama** | **1/20 (P016)** | habit 9 · need 8 · trust 3 |
| **v3 = bu paket** | **2/20 (P011, P016)** | need 10 · habit 7 · trust 3 |

- v3, ücretsiz "Yenilesem mi?"yi sıralamaya indirince **vade yenileyen mevduatçıyı** (P011) kazandı.
- Ama **döviz/altın tutan** üç kişi (P013, P019, P020) Premium'u "benim için değil" diye reddetti; P020 v1'de alıyordu. Premium'un adı ve vitrini sadece mevduatçıyı konuşmamalı.
- Ömür boyu ₺599 iki kişide "o zaman alırım"a yaklaştırdı (P010, P013), ikisi de satın almaya dönüşmedi.

**Dürüst okuma:** 20 kişide 1–2 alıcı arası oynama istatistiksel gürültü sınırında. Teklif tarafında kazanılabilecek şeyin çoğu alındı; kalan engeller **ürün** (fon/hisse fiyatı, ileriye dönük mevduat faizi karşılaştırması), **güven** (yorum) ve **pazar alışkanlığı** (abonelik reddi). Sonraki adım panel değil, gerçek alıcı testi.

## 6. Ürüne geri bildirim (öncelik sırası)

1. **Ücretsiz "Yenilesem mi?"yi sıralamaya indir;** lira farkı ve 3/12 ay Premium (`renew/[id].tsx`, `entitlements.ts`).
2. **Premium vitrinini iki kitleye böl:** paywall'da mevduatçıya "Vade Günü", döviz/altın tutana "reel getiri alarmı + kişisel sepet + kıyas" (bağlamsal `feature` zaten var).
3. **İleriye dönük karar:** vade günü "bugün ilan edilen mevduat faizleriyle yenilersen beklenen reel getiri" — TCMB'nin yayımladığı ortalama mevduat faizi ve beklenti anketiyle (banka bazında veri lisans/kaynak kontrolü gerektirir).
4. **Ömür boyu ₺599 testi.**
5. **Fon fiyatları (TEFAS)** — en çok tekrar eden "fikrimi değiştirir" cevabı (10+ kişi).
