# Marka — Paraölçer (v2)

> **v2 (30.10.2026):** Ad, renk, yazı tipi ve ses değişmedi. Uygulamada hazır olanlar: gizlilik sayfası (`ofzorbaci.github.io/Paraolcer/gizlilik.html`), tutarsız paylaşılabilir karne görseli (temas noktası 4 için), yöntem ekranı, mağaza yorumu isteme. Hâlâ açık: TÜRKPATENT ön araştırması, alan adı (gizlilik sayfasını kendi alan adına taşımak güveni artırır), hesap adları.

Ad (**Paraölçer**) ve logo konsepti (gösterge kadranlı "P") kurucu tarafından zaten seçildi ve uygulamaya işlendi (`app.json`, `assets/brand/paraolcer-icon.svg`, `src/constants/theme.ts`). Bu dosya seçimi konumlandırmaya göre sınar, kontrol listesini verir ve sesi/temas noktalarını yazar.

## 1. Ad adayları (karşılaştırma için 10)

| ad | tarz | ne söylüyor | sesli / ikonda | risk |
| --- | --- | --- | --- | --- |
| **Paraölçer** (seçili) | tanımlayıcı | "paranı ölçer" — ürünün tam işi | kolay, 4 hece; ikonda "P" | "ö" harfi: mağaza araması, alan adı ve URL'de "paraolcer" yazılır; marka tescilinde tanımlayıcı sayılma riski |
| Reel Getiri Pusulası | tanımlayıcı | eski çalışma adı | uzun, ikonda çalışmaz | jenerik |
| Gerçek Getiri | tanımlayıcı | repo adı | net ama jenerik | tescil zor |
| Alım Gücü | tanımlayıcı | maaş/birikim tarafı | net | jenerik ifade |
| Erime | çağrışımlı | "param eriyor mu?" | akılda kalır, olumsuz | negatif his |
| Karne | çağrışımlı | aylık para karnesi | sıcak, Türkçe | çok genel kelime |
| Terazi | çağrışımlı | ölçmek, denge | kısa | başka finans markalarıyla çakışma ihtimali |
| Reelim | uydurma | "benim reel getirim" | kısa, ikona uygun | anlamı ilk duyuşta belirsiz |
| SPA Ölçer | kurucunun markası | kanal (SerbestPiyasaAnaliz) ile bağ | kanal kitlesine tanıdık | uygulama kanaldan bağımsız büyüyemez |
| Enflasyonmetre | tanımlayıcı | doğrudan enflasyon | uzun | jenerik, politik çağrışım |

**Kısa liste:** Paraölçer, Karne, Reelim. **Öneri: Paraölçer'de kal.** Konumlandırmayla birebir ("ölçer" = karne/ölçüt), rakiplerin adlarına (Bistify, Cüzdan, Temettü, İyi Gelir, FinAIEra) benzemiyor, ürün zaten bu adla hazır. "Aylık Para Karnesi" Premium'un adı olarak "Karne"nin sıcaklığını zaten taşıyor.

### Kurucunun bitirmesi gereken kontroller

Sadece açık aramalar yapabiliyorum; tescil bir marka vekili/avukat tarafından doğrulanır ve kurucu tescil ettirene kadar hiçbir şey tescilli değildir. Bu hukuki tavsiye değil.

- **Marka (Türkiye):** [TÜRKPATENT marka araştırma](https://www.turkpatent.gov.tr/arastirma-yap?form=trademark) — "paraölçer", "paraolcer", "para ölçer" için **Nice sınıfları 9** (indirilebilir yazılım/uygulama), **36** (finansal bilgi hizmetleri), **42** (SaaS/yazılım hizmeti). Yurt dışı gerekirse [EUIPO eSearch](https://euipo.europa.eu/eSearch/) ve [WIPO Global Brand Database](https://branddb.wipo.int/).
  - Not: "Para" + "ölçer" tanımlayıcı sayılabilir; logolu (şekil + kelime) başvuru daha güçlü olabilir — vekile sorulmalı.
- **Alan adı:** `paraolcer.com` ve `paraolcer.com.tr` — boş olup olmadıkları kontrol edilmedi; [nic.tr](https://www.nic.tr/) ve bir kayıt firmasından bakılmalı. Alternatif: `paraolcer.app`, `getparaolcer.com`. Şu an veri akışı `ofzorbaci.github.io/Paraolcer` altında; kendi alan adına taşınması güveni artırır (gizlilik politikası URL'si için de gerekli).
- **Hesap adları:** X `@paraolcer`, Instagram `@paraolcer`, TikTok `@paraolcer`, YouTube `@paraolcer` — kontrol edilmedi. Ana kanal zaten kurucunun kanalı; ayrı bir uygulama hesabı sadece destek/duyuru için.
- **Karışıklık:** Mağaza aramasında "Paraölçer/paraolcer" için ilgili bir sonuç bulunmadı (açık web araması, 29.10.2026); App Store ve Google Play'de yayından önce elle tekrar bakılmalı.

## 2. Söz, slogan, ses

**Tek cümlelik söz:** "Her ay, paranın gerçekte ne kadar ettiğini — kanıtıyla — söyleriz."

**Slogan (3 seçenek):**
1. **"Paran büyüyor mu, eriyor mu? Ölç."** (önerilen — mağaza alt başlığına sığar)
2. "Nominal değil, gerçek."
3. "Birikiminin aylık karnesi."

**Ses — üç sıfat:**

| sıfat | yap | yapma |
| --- | --- | --- |
| **Dürüst** | kötü haberi açıkça söyle: "Mevduatın bu ay reel %0,8 kaybettirdi." | süsleme, "fırsatı kaçırma" dili, getiri vaadi |
| **Açık** | her rakamın kaynağını ve formülünü göster | jargonu açıklamadan bırakma ("Fisher" diyorsan bir satırda açıkla) |
| **Sakin** | panik değil ölçü: "Bu bir ölçüm, tavsiye değil." | korku pazarlaması ("paran yok oluyor!") |

**Önce/sonra (pitch'ten bir satır):**
- Önce: "Mevduatını (brüt faiz, vade, stopaj), dolar/euro, altın, fon ve hisseni gir; her birinin ve toplam birikiminin TÜFE'ye göre gerçek (reel) getirisini bugünün lirasıyla gösterir."
- Sonra: "Birikimini gir, bir dakikada gör: bugünün lirasıyla gerçekten kazandın mı, kaybettin mi — TÜFE'ye ve ENAG'a göre."

## 3. Görünüm (mevcut tema üzerinden brif)

**Renkler** (`src/constants/theme.ts`, WCAG kontrastı hesaplandı):

| renk | hex | görevi | kontrast |
| --- | --- | --- | --- |
| Gece laciverti | `#0F1B2D` | ana metin, hero kart, ikon zemini | açık zeminde (`#F4F6F9`) **15,96:1** ✓ AAA; üstünde beyaz **17,28:1** ✓ |
| Ölçü mavisi | `#1D4ED8` | vurgu, "koruyor" (pozitif) | beyaz metin üstünde **6,70:1** ✓ AA; açık zeminde **6,19:1** ✓ |
| Erime turuncusu | `#C2410C` | "eritiyor" (negatif) | açık zeminde **4,78:1** ✓ AA (normal metin), beyaz zeminde 5,18:1 ✓ |

Karanlık tema: metin `#E6EBF4` / zemin `#0A101C` 15,9:1; negatif `#FB8F5E` 8,33:1; vurgu `#6E95FF` 6,71:1 — hepsi AA üstü.

İyi bir seçim: pozitif için yeşil yerine **mavi**, negatif için kırmızı yerine **turuncu** kullanmak hem renk körlüğüne hem "borsa uygulaması" görüntüsünden uzak durmaya yarıyor. Koruyun.

**Yazı tipleri:** Sora (başlık) + Inter (metin) — ikisi de [Google Fonts](https://fonts.google.com/), SIL Open Font License, uygulamada `@expo-google-fonts` paketleriyle zaten yüklü. Lisans sorunu yok.

**Logo brifi** (seçili konsept D: kasesi gösterge kadranı olan "P"):
- Söylemesi gereken: ölçüm, doğruluk, sakinlik.
- Çalışması gereken yerler: **32 px uygulama ikonu** (kadran ibresi 32 px'de görünür kalmalı — ibreyi kalınlaştır, ince ölçek çizgilerini 48 px altında kaldır), Android tek renk (monochrome) ikon, YouTube video köşesi, X profil görseli.
- Kaçınılacaklar: yukarı ok / boğa / grafik çizgisi (yatırım uygulaması gibi görünür, getiri vaadi çağrıştırır), TL simgesi (ürün döviz/altını da ölçüyor), rakip ikonlarına benzer cüzdan şekli.

**İlk beş temas noktası:**
1. **Mağaza sayfası:** başlık "Paraölçer: Reel Getiri Karnesi", alt başlık "Paran büyüyor mu, eriyor mu? Ölç." İlk ekran görüntüsü: büyük tek sayı ("Birikimin bugünün lirasıyla: −%3,2 · ENAG: −%11") — örnek veriyle olduğu açıkça yazılı.
2. **İlk açılış (paket yerine):** kurulum yok; "Sadece mevduatını gir" tek alanı ya da "Temettü/Excel dosyamı içe aktar" — 60 saniyede ilk sonuç (kurulun şartı).
3. **Onay (deneme başlatınca):** "14 günün başladı. 12. gün sana hatırlatacağız; istersen tek dokunuşla iptal." — sürpriz ücret yok.
4. **İlk sosyal paylaşım:** lansman günü (3 Aralık, TÜFE açıklaması sonrası) gerçek kasım rakamıyla "Mevduat bu ay reel olarak %X…" görseli; altta "yatırım tavsiyesi değildir".
5. **İlk şikâyete yanıt (mağaza yorumu):** "Haklısın, [sorun]. [Tarih]'teki sürümde düzelttik / yol haritasında, [ne zaman]. Hesap yöntemi burada: [link]. — Ömer, Paraölçer" — isimle, savunmasız, tarihli.
