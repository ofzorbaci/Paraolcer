# Price sensitivity

50 complete answers. Simulated buyers: use this to pick what to test, not as the final word.

| point | price | what it means |
| --- | ---: | --- |
| PMC | $15.66 | below this, too many think it is too cheap to be good |
| OPP | $20.84 | as many say too cheap as too expensive: the least resistance |
| IPP | $30.49 | as many call it a bargain as call it expensive |
| PME | $60.11 | above this, too many say it is too expensive to buy |

**Acceptable range: $15.66 to $60.11.**

Median answers: too cheap $10.00, a bargain $25.00, getting expensive $50.00, too expensive $90.00.

Your current price, $49.99, is **inside** the acceptable range.
