# Pazarlama — Paraölçer (v2)

> **v2 değişiklikleri (30.10.2026):** Uygulama artık paylaşılabilir karne görseli, "Nasıl hesaplandı?" ekranı, alarm/hedef ve Excel içe aktarma içeriyor; hook'lar bunlara göre güncellendi. Konumlandırma mevduatçıda kalıyor, döviz/altın tutana ikinci mesaj eklendi. Temettü dalgası küçültüldü (kullanıcıları hisse yatırımcısı; fon/hisse fiyatı hâlâ elle). Ücretli reklam: ilk 60 gün yok (CFO başabaş 17 abone).

Kanıtlar: `panel/results.md` (v2, 50 alıcı, güncel uygulama), `panel-offer` (teklif re-testi, 20 alıcı), `competitors.md`, `offer.md`, `pricing.md`, `cfo.md`.

**Lansman günü: Perşembe 3 Aralık 2026** — TÜİK'in kasım TÜFE'sini açıkladığı gün. Ürünün kendisi "TÜFE günü karnesi" olduğu için lansman da o güne bağlanıyor. Kampanya: 19 Kasım → 19 Aralık.

## 1. Konumlandırma

Panelde alanlar: **maaşlı, her ay vade yenileyen mevduatçı** (P016, re-testte P011) ve **TÜİK'e güvenmeyen, kendi enflasyonunu isteyen** (P041). Döviz/altın tutanlar re-testte "Vade Günü" vitrinini "benim için değil" diye reddetti (P013, P019, P020) — onlara ikinci mesaj gerekiyor. Fon/hisse yatırımcıları elle fiyat yüzünden geçiyor; ilk kitle onlar değil, Temettü kullanıcılarının çoğu hisse yatırımcısı olduğu için Temettü dalgası küçültüldü.

1. **(Önerilen)** "Her ay vadesini yenileyen ve 'param gerçekten büyüyor mu?' diye düşünen tasarruf sahibi için, Paraölçer; mevduat, dolar ve altını stopaj sonrası TÜFE **ve** ENAG'a göre aynı ekranda ölçen tek reel getiri karnesidir — tek seferlik hesaplayıcıların aksine birikimini hatırlar, portföy uygulamalarının aksine mevduatı doğru hesaplar."
   *Kanıt:* need gerekçelerinin çoğu "vade yenilerken ne yapacağımı söylemiyor"; P016 bu yüzden aldı; hesaplayıcılar kayıt tutmuyor; Bistify/FinAIEra mevduat/stopaj modellemiyor (`competitors.md`).
2. "TÜİK rakamına güvenmeyenler için: kendi enflasyonunla ölç." *Kanıt:* panelde 13 kişi TÜFE'ye güvenmiyor. Ama tek başına politik ve kırılgan bir mesaj; ikinci mesaj olarak kullanılmalı.
3. "Temettü kapanıyor: portföyünü 1 dakikada taşı, üstüne reel getirini gör." *Kanıt:* Temettü'nün 430 değerlendirmesi ve 1 Ocak 2027 kapanışı. Güçlü ama süreli (Ocak sonrası geçersiz) → kampanya içinde bir dalga.

## 2. Kanallar

| kanal | neden bu alıcı | maliyet | işe yaradığını nasıl anlarız | karar |
| --- | --- | --- | --- | --- |
| **Kendi YouTube kanalı (≈90 bin)** | panelde "Follows a finance YouTuber" ve "Sunday video" en sık geçen güven kaynağı | ₺0 (zaman) | açıklama linkinden indirme (UTM / mağaza kampanya linki) | **BAŞLA** — ana kanal |
| **X (tek tweet, görselli)** | TÜFE günü finans gündeminin aktığı yer; "Paraölçer reel getirisi" ölçütünü kurmak için | ₺0 | tweet başı link tıklaması | **BAŞLA** |
| **Investing Türkiye yazısı** | aynı kitle, arama trafiği | ₺0 | yazıdan tıklama | **BAŞLA** (kısa, videoya/uygulamaya yönlendiren) |
| YouTube Shorts / Ekonomi Sözlüğü serisi | "reel getiri" tanımı = kısa video formatına birebir | ₺0 | Shorts → kanal → uygulama | ek, haftada 1 |
| Ücretli reklam (Meta/Google UAC) | — | ₺2.000/ay (tahmin) | — | **YAPMA (ilk 60 gün)** — CFO v2: reklamsız başabaş 17 abone; aşağıdaki azami edinme maliyeti reklamı kârsız gösteriyor |
| Diğer finans YouTuber'ları ile ücretli işbirliği | güven transferi | bilinmiyor | — | **SONRA** — önce kendi kanalının dönüşümü ölçülsün; yapılırsa "reklam/işbirliği" açıkça belirtilir |
| Ekşi/Reddit/Telegram grupları | — | ₺0 | — | **YAPMA** — kurucunun markasına spam riski |

## 3. 30 günlük kampanya (19 Kasım – 19 Aralık 2026)

Kanal ritmi: Cumartesi = özel ana video, Pazar = Haftalık Piyasa Analizi.

| tarih | kanal | ne çıkıyor |
| --- | --- | --- |
| Per 19 Kas (L−14) | X | Teaser: "2021'de 100 bin TL'lik mevduat bugün kaç para? Cevabı bir uygulamaya çevirdim. 3 Aralık." + Kurucu Üye bekleme listesi linki |
| Cmt 21 Kas | YouTube (ana video) | "Mevduat, dolar, altın: son 5 yılda hangisi gerçekten kazandırdı? (TÜFE ve ENAG'a göre)" — sonunda uygulamanın ilk ekranı ve bekleme listesi |
| Paz 22 Kas | Haftalık Piyasa Analizi | sonda 20 sn: "Uygulamayı 3 Aralık'ta TÜFE günü açıyorum, bekleme listesi açıklamada" |
| Sal 24 Kas | Shorts | Ekonomi Sözlüğü: "Reel getiri nedir?" (Fisher formülü, 45 sn) |
| Per 26 Kas | X | "Yapım aşaması": stopajlı mevduat hesabının formülü, tek görsel — güven için yöntem açık |
| Cmt 28 Kas | YouTube (ana video) | "Maaş zammın enflasyonu karşıladı mı? Kendin hesapla" — uygulamadaki maaş hesabı ekranı |
| Paz 29 Kas | Haftalık Piyasa Analizi | sonda: Temettü kapanıyor → "dışa aktarma dosyanı Paraölçer'e taşıyabileceksin" |
| Sal 1 Ara | X + Investing | "Perşembe TÜFE açıklanıyor. Paraölçer aynı gün yayında." |
| **Per 3 Ara (LANSMAN, TÜFE günü)** | X (10:00 TÜFE'den hemen sonra) | "Kasım TÜFE açıklandı. Mevduat bu ay reel olarak %X kazandırdı / kaybettirdi. Kendi birikimin için: Paraölçer, bugün App Store ve Google Play'de." (gerçek rakam, açıklamadan sonra) |
| Per 3 Ara | Investing Türkiye | kısa yazı: "Kasım TÜFE'si sonrası mevduat, dolar ve altının reel getirisi" + uygulama linki |
| Per 3 Ara | Bekleme listesi | e-posta/mesaj: "Yayındayız. Kurucu Üye fiyatı 31 Ocak'a kadar" |
| Cmt 5 Ara | YouTube (ana video) | "Paranın karnesi: Kasım'da kim korudu, kim eritti?" — uygulamanın canlı kullanımı, 14 gün deneme ve Kurucu Üye |
| Paz 6 Ara | Haftalık Piyasa Analizi | açıklamada link, sonda 15 sn |
| Sal 8 Ara | Shorts | "Mevduatını yenilemeden önce 1 dakika: stopaj sonrası reel getiri" |
| Per 10 Ara | X | ilk hafta açık rakamları (indirme, gerçek sayı) + en çok istenen özellik — **sahte sayı yok** |
| Cmt 12 Ara | YouTube (ana video) | "Temettü kapanıyor: portföyünü nereye taşımalısın?" — taşıma bonusu, tarafsız karşılaştırma |
| Paz 13 Ara | Haftalık Piyasa Analizi | link |
| Sal 15 Ara | X | ilk gerçek kullanıcı karnelerinden biri (izinli, tutarsız paylaşılabilir görsel — uygulamada hazır) |
| Per 17 Ara | X + Investing | PPK haftası (karar tarihi PPK takviminden teyit edilmeli): "Faiz kararı mevduatının reel getirisini nasıl değiştirir?" + bildirim özelliği |
| Cmt 19 Ara (L+16) | YouTube (ana video) | Yıl sonu: "2026'da paranın gerçek karnesi" — Kurucu Üye hatırlatması (31 Ocak) |

**Yeni bir şey yokken:** "yöntem" paylaşımları (formüller, TÜİK/ENAG farkı), kullanıcıların sorduğu sorular, yapım aşaması (veri akışı nasıl çalışıyor), yol haritası oylaması (fon fiyatları otomatik olsun mu?).

## 4. On hook

| # | format | hook | cevapladığı itiraz / sebep |
| --- | --- | --- | --- |
| 1 | video açılışı (3 sn) | "Mevduatın %45 kazandırdı. Ama gerçekten kazandırdı mı?" | "zaten biliyorum" |
| 2 | video açılışı | "Bankan sana nominal faizi söyler. Gerçek faizi kimse söylemez." | "bankam ekler" |
| 3 | X | "TÜFE'ye göre kazandın, ENAG'a göre kaybettin. İkisini aynı ekranda gör." | "TÜİK benim enflasyonum değil" |
| 4 | video açılışı | "Vaden yarın doluyor. Yenile mi, dolar mı, altın mı?" | "ne yapacağımı söylemiyor" |
| 5 | X / Shorts | "Maaşına zam geldi. Kaç lira kayıptasın?" | maaş sorusu (P017) |
| 6 | mağaza başlığı | "Hesap yok. Veri telefonunda. Sonuç bir dakikada." | güven, veri gizliliği |
| 7 | video açılışı | "Excel'de enflasyon takip edenler: dosyanı at, gerisini uygulama yapsın." | spreadsheet keeper |
| 8 | X | "Dolar ve altın tutanlar: reel getirin eksiye düşünce haber verelim." | döviz/altın tutan ("Vade Günü benim için değil") |
| 9 | mağaza / paywall | "Ücretsiz: param eridi mi? Premium: vade günü ne yapmalıyım?" | "ücretsiz yetiyor" |
| 10 | video açılışı | "Formülü gizli olan hesaba güvenme. Bizimki açık." | "rakamlar doğru mu?" |

Yasal not: "yatırım tavsiyesi değildir" her videoda/paylaşımda; getiri vaadi yok ("kazandırır" değil, "ölçer"). Bu hukuki tavsiye değil; SPK/reklam kuralları için bir uzmana danışılmalı.

## 5. Bütçe ve rakamlar

**Bütçe (ilk 60 gün):** ₺0 ücretli medya. CFO'nun ₺10.000 lansman kalemi: ₺5.000 mağaza görselleri ve kısa tanıtım videosu, ₺5.000 yedek (60. günden sonra en iyi çalışan kanalda test). CFO v2 modelinde ücretli reklam yok; 60. günden sonra ancak edinme maliyeti ölçülerek açılır (₺2.000/ay başabaşı 17 → 87 aboneye çıkarır).

**Bir müşteriye ödenebilecek azami tutar:**
- Katkı: ₺28,33 / abone-ay (`cfo.md`). Panelde alanlar ilk ay ortalama 1 kez alıyor (yıllık plan).
- Yıllık plan ilk yıl katkısı: ₺399,99 ÷ 1,20 × 0,85 = **₺283**.
- Başlangıç masrafını tehlikeye atmadan, 4 ayda geri dönen bir edinme maliyeti: 4 × ₺28,33 ≈ **₺113 / ödeyen abone**.
- Ücretsiz→ücretli dönüşüm %2,5 (tahmin) ise: ₺113 × 0,025 ≈ **₺2,8 / indirme**. Türkiye'de ücretli uygulama yükleme maliyeti bunun üzerindeyse ücretli reklam kârsızdır — bu yüzden ilk 60 gün organik.

**Haftalık izlenecek üç rakam:**

| rakam | nereden | "bir şey değiştir" eşiği |
| --- | --- | --- |
| Video/tweet başına indirme | mağaza kampanya linkleri | ana video başına < 300 indirme → hook ve çağrıyı değiştir |
| Deneme başlatma oranı (indirenlerin) | RevenueCat | < %8 → paywall'ı ve "Yenilesem mi?" tadımlığını değiştir |
| Deneme → ücretli | RevenueCat | < %30 → deneme süresi içinde ilk karne gelmiyor mu, kontrol et; fiyat testi B (₺39,99/₺299,99) |

(Eşikler tahmin; ilk iki haftanın gerçek rakamlarıyla güncellenmeli.)
