# Özet (v2, 30.10.2026)

**Karar: Not yet (henüz değil).** Birim ekonomisi ve 1. yıl kârı geçiyor, alıcı paneli geçmiyor: güncel uygulamayla 50 simüle alıcıdan **2'si** alıyor (**%4**, çıta %25; v1 %2). **Değişmesi gereken:** ücretsiz katman karar anını fazla veriyor ve Premium döviz/altın tutanı konuşmuyor (`/founder-offer`); asıl hakem gerçek alıcı testi (`/founder-launch`). %25 çıtası tek seferlik satışlar için; freemium uygulamada gerçek ücretli dönüşüm çok daha düşük olur.

**Ne ve kim için:** Paraölçer, birikimin bugünün lirasıyla enflasyonu (TÜFE ve ENAG) yenip yenmediğini gösteren ve her vade gününde "Yenilesem mi?" kıyasını yapan hesapsız mobil uygulama. İlk kitle: her ay vade yenileyen, TÜİK'e tam güvenmeyen maaşlı mevduatçı.

**Üç rakam** (`cfo.md`, TL, KDV hariç, projeksiyon): katkı **₺28,33 / abone-ay (%85)**, 250 abonede **%79 marj**; başabaş **17 ödeyen abone/ay**; 1. yıl işletme kârı **₺42.062** (hacim −%70'te başlangıç sonrası −₺5.500).

**v1 → v2 ne değişti:** Ürün kurulun v1 şartlarının çoğunu karşıladı (ilk dakikada sonuç, yöntem ekranı, yedek/kilit, Excel içe aktarma, sınırsız ücretsiz varlık, ENAG özeti). Kurul puanı 5,3 → **5,7**. Panelde "3 varlık yetiyor" ve "ENAG kilitli" itirazları kayboldu; yerine **"ücretsiz zaten yetiyor"** (19 kişi) geldi. Teklif re-testinde (ücretsiz "Yenilesem mi?" sadece sıralama, lira farkı Premium, ömür boyu ₺599) aynı 20 alıcıda 1 → 2 alıcı.

**Kurul ve panel neyde anlaştı:** fon/hisse fiyatının elle girilmesi en kalıcı zayıflık; Premium'un "asıl ne için ödüyorum?" cevabı net değil; yorum yokken güven düşük. **Ayrıldıkları yer:** kurulun Ürün merceği Premium'u daraltmak istiyor; panel ise döviz/altın tutanlar için Premium'da kendine ait bir şey arıyor.

**En büyük risk:** gerçek dönüşümün simülasyonun da altında kalması (abonelik reddi 22 kişi). Plan: kanal üzerinden organik lansman, ilk 30 günde ≥50 yorum, ömür boyu fiyat testi, reklam yok.

**Başlamak için gereken:** **₺14.246** nakit. İlk test: fiyatlı bekleme listesi (21 Kas–2 Ara, ≥1.000 kayıt) ve Kurucu Üye satışı (20 Aralık'a kadar ≥50 ödeyen).

**Bu hafta yapılacak tek şey:** Apple Developer + Google Play hesaplarını aç, abonelik ürünlerini (aylık, yıllık, Kurucu Üye yıllık, ömür boyu) mağazalarda tanımla ve RevenueCat anahtarlarını `app.json`'a gir — 19 Kasım mağaza incelemesinin kritik yolu.

Panel simüle alıcılardır, rakamlar projeksiyondur; finansal, hukuki ya da vergi tavsiyesi değildir.
