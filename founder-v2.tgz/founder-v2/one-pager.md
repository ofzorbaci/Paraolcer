# Paraölçer — tek sayfa (v2)

**Karar: Not yet** (birim ekonomisi ✓, 1. yıl kârı ✓, alıcı paneli ✗ — 50'de 2, %4; çıta %25).

**Sorun.** Tasarruf sahibi nominal faizi ve kuru görür; birikiminin enflasyon karşısında gerçekten büyüyüp büyümediğini ve vade günü ne yapması gerektiğini bilmez.

**Müşteri.** Her ay vade yenileyen, TÜİK'e tam güvenmeyen maaşlı mevduatçı; ikinci kitle döviz/altın tutan. Kurucunun ≈90 bin abonelik kanalı, X ve Investing Türkiye.

**Teklif ve fiyat.** Ücretsiz: sınırsız varlık, reel getiri (TÜFE + ENAG satırı), TÜFE günü özet karne, ayda 1 "Yenilesem mi?", Excel içe/dışa aktarma, kilit, yedek, hesap yok. Premium: her vadede tam "Yenilesem mi?" (lira farkı, 1/3/12 ay), varlık bazında ENAG ve kişisel sepet, alarm ve hedef, grafikler, çoklu portföy. **Aylık ₺49,99 · yıllık ₺399,99**, 14 gün deneme. Kurucu Üye (31 Ocak 2027'ye kadar): yıllık ₺299,99 kilitli ya da ilk 500 kişiye ömür boyu (₺999; ₺599 test önerisi).

| rakam (TL, KDV hariç, projeksiyon) | |
| --- | ---: |
| Net fiyat | ₺33,33 / ödeyen abone-ay |
| Kâr marjı (planda) | %79 |
| Başabaş | 17 ödeyen abone / ay |
| 1. yıl işletme kârı | ₺42.062 |
| Başlangıç harcaması | ₺14.246 |
| Kendini ödeyene kadar nakit | ₺14.246 |
| Başlangıç parası geri dönüşü | 7. ay |
| Alıcı paneli | 2 alır · 48 geçer |

**Kanıt.**
- Panel (simüle, aynı 50 alıcı): v1 %2 → v2 %4. Kabul edilebilir aylık fiyat ₺16–60.
- Kurul: 3 × şartlı fonla, ortalama 5,3 → 5,7.
- Rakip boşluğu: mevduat/stopaj, ENAG/kişisel enflasyon, vade günü kararı ve hesapsız gizlilik başka hiçbir yerli uygulamada birlikte yok; Bistify fon/hisse ve otomatik fiyatta açıkça önde.
- Gerçek test: **henüz yok**.

**Para ne için.** ₺1.246 Google Play kaydı, ₺3.000 KVKK incelemesi (tahmin), ₺10.000 lansman görselleri ve yedek test bütçesi (tahmin); Apple ₺411/ay. Ücretli reklam yok.

**İstek.** Dış yatırım yok. 3 Aralık 2026 (TÜFE günü) lansmanı; tek başarı ölçüsü **20 Aralık'a kadar ≥50 ödeyen Kurucu Üye**.

Panel simüle alıcılardır, rakamlar projeksiyondur. Finansal, hukuki ya da vergi tavsiyesi değildir.
